﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProgrammerInterface
{
    public enum ExitCodes
    {
        /// <summary>
        /// 0 Success 
        /// </summary>
        NoError = 0,
        /// <summary>
        /// 1 Could not compare External NVM content with the HEX file 
        /// </summary>
        ErrorCantCompareEEPROM = 1,
        /// <summary>
        /// 2 Could not compare Flash content with the HEX file 
        /// </summary>
        ErrorCantCompareFlash = 2,
        /// <summary>
        /// 3 Could not compare SRAM content with the HEX file 
        /// </summary>
        ErrorCantCompareSRAM = 3,
        /// <summary>
        /// 4 Could not detect the Z-Wave device 
        /// </summary>
        ErrorCantDetectDevice = 4,
        /// <summary>
        /// 5 Could not erase the External NVM content 
        /// </summary>
        ErrorCantEraseEEPROM = 5,
        /// <summary>
        /// 6 Could not erase the Flash content 
        /// </summary>
        ErrorCantEraseFlash = 6,
        /// <summary>
        /// 7 Could not get the firmware version 
        /// </summary>
        ErrorCantGetFirmwareVersion = 7,
        /// <summary>
        /// 8 Could not initialize External NVM 
        /// </summary>
        ErrorCantInitEEPROM = 8,
        /// <summary>
        /// 9 Could not read the Lock Bits 
        /// </summary>
        ErrorCantLockBitsRead = 9,
        /// <summary>
        /// 10 Could not set the Lock Bits. If you are trying to write lock bits not for the first time - erase device first. If the device is not erasable - replace it by a new one. 
        /// </summary>
        ErrorCantLockBitsSet = 10,
        /// <summary>
        /// 11 Could not read the application RF settings from Flash 
        /// </summary>
        ErrorCantReadAppRfSettings = 11,
        /// <summary>
        /// 12 Could not read the External NVM content 
        /// </summary>
        ErrorCantReadEEPROM = 12,
        /// <summary>
        /// 13 Could not read the External NVM options 
        /// </summary>
        ErrorCantReadEEPROMOptions = 13,
        /// <summary>
        /// 14 Could not read the Flash content 
        /// </summary>
        ErrorCantReadFlash = 14,
        /// <summary>
        /// 15 Could not read the Flash options 
        /// </summary>
        ErrorCantReadFlashOptions = 15,
        /// <summary>
        /// 16 Could not read the general options from Flash 
        /// </summary>
        ErrorCantReadGeneralRfSettings = 16,
        /// <summary>
        /// 17 Could not read the Home ID 
        /// </summary>
        ErrorCantReadHomeId = 17,
        /// <summary>
        /// 18 Could not read the SRAM content 
        /// </summary>
        ErrorCantReadSram = 18,
        /// <summary>
        /// 19 Cannot reset connected Z-Wave Module 
        /// </summary>
        ErrorCantResetZWaveModule = 19,
        /// <summary>
        /// 20 Could not switch the device to BootLoader mode. 
        /// </summary>
        ErrorCantSetBootLoaderMode = 20,
        /// <summary>
        /// 21 Could not switch the chip operation mode. Required operation mode may be disabled by a lock bit. 
        /// </summary>
        ErrorCantSetChipWorkingMode = 21,
        /// <summary>
        /// 22 Could not switch the chip to Programming mode 
        /// </summary>
        ErrorCantSetProgrammingMode = 22,
        /// <summary>
        /// 23 Could not upgrade the firmware of the device 
        /// </summary>
        ErrorCantUpgradeFirmware = 23,
        /// <summary>
        /// 24 Could not write the application RF settings to Flash 
        /// </summary>
        ErrorCantWriteAppRfSettings = 24,
        /// <summary>
        /// 25 Could not write content of the HEX file to External NVM   
        /// </summary>
        ErrorCantWriteEEPROM = 25,
        /// <summary>
        /// 26 Could not write content of the HEX file to Flash 
        /// </summary>
        ErrorCantWriteFlash = 26,
        /// <summary>
        /// 27 Could not write the application RF settings to Flash 
        /// </summary>
        ErrorCantWriteFlashOptions = 27,
        /// <summary>
        /// 28 Could not write the general options to Flash 
        /// </summary>
        ErrorCantWriteGeneralRfSettings = 28,
        /// <summary>
        /// 29 Could not write the Home ID 
        /// </summary>
        ErrorCantWriteHomeId = 29,
        /// <summary>
        /// 30 Could not write content of the HEX file to SRAM 
        /// </summary>
        ErrorCantWriteSram = 30,
        /// <summary>
        /// 31 Comparison of External NVM content with the HEX file failed 
        /// </summary>
        ErrorCompareEepromFailed = 31,
        /// <summary>
        /// 32 Comparison of SRAM content with the HEX file failed 
        /// </summary>
        ErrorCompareSRAMFailed = 32,
        /// <summary>
        /// 33 The HEX file for External NVM is not specified or specified file does not exist. 
        /// </summary>
        ErrorEEPROMHexFileNotSpecified = 33,
        /// <summary>
        /// 34 The HEX file for Flash is not specified or specified file does not exist. 
        /// </summary>
        ErrorFlashHexFileNotSpecified = 34,
        /// <summary>
        /// 35 Hex file not valid. Address out of range. 
        /// </summary>
        ErrorHexFileDataOutOfRange = 35,
        /// <summary>
        /// 36 Hex file not valid 
        /// </summary>
        ErrorHexFileNotValid = 36,
        /// <summary>
        /// 37 End value for Home ID must be greater than Start value 
        /// </summary>
        ErrorInvalidEndHomeId = 37,
        /// <summary>
        /// 38 RF frequency was not selected 
        /// </summary>
        ErrorRfFrequencyNotSelected = 38,
        /// <summary>
        /// 39 'Start Home Id' or 'End Home Id' was not specified 
        /// </summary>
        ErrorStartEndHomeIdEmpty = 39,
        /// <summary>
        /// 40 Undefined general option was encountered 
        /// </summary>
        ErrorUndefinedRfSettings = 40,
        /// <summary>
        /// 41 Could not initialize MTP 
        /// </summary>
        ErrorCantInitMtp = 41,
        /// <summary>
        /// 42 Could not read the MTP content 
        /// </summary>
        ErrorCantReadMtp = 42,
        /// <summary>
        /// 43 Could not erase the MTP content 
        /// </summary>
        ErrorCantEraseMtp = 43,
        /// <summary>
        /// 44 Could not program MTP 
        /// </summary>
        ErrorCantProgramMtp = 44,
        /// <summary>
        /// 45 Could not compare MTP content with the HEX file 
        /// </summary>
        ErrorCantCompareMtp = 45,
        /// <summary>
        /// 46 Programming of MTP failed 
        /// </summary>
        ErrorProgramMtpFailed = 46,
        /// <summary>
        /// 47 Comparison of MTP content with the HEX file failed 
        /// </summary>
        ErrorCompareMtpFailed = 47,
        /// <summary>
        /// 48 HEX file for MTP not specified 
        /// </summary>
        ErrorMtpHexFileNotSpecified = 48,
        /// <summary>
        /// 49 Reading the HEX file failed 
        /// </summary>
        ErrorHexFileReadingFailed = 49,
        /// <summary>
        /// 50 Read/Write operation timeout. 
        /// </summary>
        ErrorReadWriteTimeout = 50,
        /// <summary>
        /// 51 Could not read the NVR content
        /// </summary>
        ErrorCantReadNvr = 51,
        /// <summary>
        /// 52 Could not write the NVR content
        /// </summary>
        ErrorCantWriteNvr = 52,
        /// <summary>
        /// 53 Check CRC failed
        /// </summary>
        ErrorCheckCrcFailed = 53,
        /// <summary>
        /// 251 Other errors
        /// </summary>
        UnspecifiedError = 251,
    }
}
