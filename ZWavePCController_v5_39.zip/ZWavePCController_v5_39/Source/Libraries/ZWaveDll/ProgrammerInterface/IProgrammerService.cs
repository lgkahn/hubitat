﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utils.UI.Enums;

namespace ProgrammerInterface
{
    public interface IProgrammerService
    {
        void Initialize(Action<string, LogLevels, LogIndents, LogIndents> OnLogText, 
            Func<string, LogLevels, LogIndents, LogIndents, bool> OnConfirmation, 
            Action<string> OnAssertAndReset);
        int CreateProgrammer();
        ExitCodes ProgramFlash(string dataSource, byte[] hexData);
        ExitCodes ProgramFlash(string dataSource, string hexFileName);
        ExitCodes ProgramFlash(int programmer, string dataSource, byte[] hexData);
        ExitCodes ProgramFlash(int programmer, string dataSource, string hexFileName);
        void Dispose(int programmer);
    }
}
