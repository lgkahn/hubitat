﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZWave.Layers;
using ZWave.Layers.Frame;

namespace ZWave.ZipApplication
{
    public class ZipFrameLayer : FrameLayer
    {
        public override IFrameClient CreateClient()
        {
            IFrameClient ret = new ZipFrameClient(TransmitCallback);
            return ret;
        }
    }
}
