﻿using System;
using ZWave.Layers;
using System.Collections;
using ZWave.Layers.Transport;
using System.Net;
using Utils;

namespace ZWave.ZipApplication
{
    public class Dtls1ClientTransportLayer : TransportLayer, IDisposable
    {
        private object _lisneterLock = new object();

        public event Action<IPAddress, ushort> UsolicitedDataReceived;

        private Dtls1ClientTransportListener _listener;
        public override ITransportListener Listener
        {
            get
            {
                lock (_lisneterLock)
                {
                    return _listener;
                }
            }

            set
            {
                lock (_lisneterLock)
                {
                    if (_listener != null)
                    {
                        _listener.Close();
                        _listener.DataReceived -= Listener_ReceiveDataCallback;
                    }
                    _listener = value as Dtls1ClientTransportListener;
                    _listener.DataReceived += Listener_ReceiveDataCallback;
                }
            }
        }

        private Dtls1ClientTransportListener _listenerSecond;
        public Dtls1ClientTransportListener ListenerSecond
        {
            get
            {
                lock (_lisneterLock)
                {
                    return _listenerSecond;
                }
            }

            set
            {
                lock (_lisneterLock)
                {
                    if (_listenerSecond != null)
                    {
                        _listener.Close();
                        _listenerSecond.DataReceived -= Listener_ReceiveDataCallback;
                    }
                    _listenerSecond = value as Dtls1ClientTransportListener;
                    _listenerSecond.DataReceived += Listener_ReceiveDataCallback;
                }
            }
        }

        void Listener_ConnectionClosed(string address, ushort portNo)
        {
            lock (_lisneterLock)
            {
                var client = _clients[address + portNo.ToString()] as Dtls1ClientTransportClient;

                if (client != null)
                {
                    client.InnerWriteDataCallback = null;
                }
            }
        }

        void Listener_ReceiveDataCallback(ReceivedDataArgs receivedDataArgs)
        {
            lock (_lisneterLock)
            {
                IPAddress sourceIpAddress = null;
                if (IPAddress.TryParse(receivedDataArgs.SourceName, out sourceIpAddress))
                {
                    sourceIpAddress = Tools.MapToIPv4(sourceIpAddress);
                }
                var client = _clients[sourceIpAddress.ToString() + receivedDataArgs.ListenerPort.ToString()] as Dtls1ClientTransportClient;

                if (client != null)
                {
                    client.InnerWriteDataCallback = (x) =>
                    {
                        if (_listenerSecond != null && _listenerSecond.PortNo == receivedDataArgs.ListenerPort)
                        {
                            return _listenerSecond.ResponseTo(x, receivedDataArgs.SourceName, receivedDataArgs.SourcePort);
                        }

                        return _listener.ResponseTo(x, receivedDataArgs.SourceName, receivedDataArgs.SourcePort);
                    };
                }
                else
                {
                    client = _clients[receivedDataArgs.SourceName] as Dtls1ClientTransportClient;
                }

                if (client == null)
                {
                    if (UsolicitedDataReceived != null)
                    {
                        UsolicitedDataReceived(sourceIpAddress, receivedDataArgs.ListenerPort);
                        client = _clients[sourceIpAddress.ToString() + receivedDataArgs.ListenerPort.ToString()] as Dtls1ClientTransportClient;
                        client.InnerWriteDataCallback = (x) =>
                        {
                            if (_listenerSecond != null && _listenerSecond.PortNo == receivedDataArgs.ListenerPort)
                            {
                                return _listenerSecond.ResponseTo(x, receivedDataArgs.SourceName, receivedDataArgs.SourcePort);
                            }

                            return _listener.ResponseTo(x, receivedDataArgs.SourceName, receivedDataArgs.SourcePort);
                        };
                    }
                }

                if (client != null)
                {
                    client.ReceiveDataCallback?.Invoke(new DataChunk(receivedDataArgs.Data, client.SessionId, false, client.ApiType), false);
                }
            }
        }

        private Hashtable _clients = new Hashtable();

        public override ITransportClient CreateClient(byte sessionId)
        {
            Dtls1ClientTransportClient client = new Dtls1ClientTransportClient(TransmitCallback)
            {
                SuppressDebugOutput = SuppressDebugOutput,
                SessionId = sessionId
            };
            client.Connected += Client_Connected;
            return client;
        }

        private void Client_Connected(ITransportClient client)
        {
            if (client == null)
            {
                return;
            }

            client.Disconnected += Client_Disonnected;
            if (!_clients.Contains(client.DataSource.SourceName))
            {
                _clients.Add(client.DataSource.SourceName, client);
            }
        }

        private void Client_Disonnected(ITransportClient client)
        {
            if (client == null)
            {
                return;
            }

            client.Disconnected -= Client_Disonnected;
            _clients.Remove(client.DataSource.SourceName);
            client.Dispose();
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (Listener != null)
            {
                Listener.Dispose();
            }
            if (ListenerSecond != null)
            {
                ListenerSecond.Dispose();
            }
            if (_clients != null && _clients.Count > 0)
            {
                foreach (ITransportClient client in _clients.Values)
                {
                    client.Disconnected -= Client_Disonnected;
                    client.Dispose();
                }
            }
        }

        #endregion

        public void RegisterClient(string key, ITransportClient client)
        {
            if (!_clients.Contains(key))
            {
                _clients.Add(key, client);
            }
            else
            {
                _clients[key] = client;
            }
        }

        public void UnregisterClient(string key)
        {
            if (_clients.Contains(key))
            {
                _clients.Remove(key);
            }
        }
    }
}
