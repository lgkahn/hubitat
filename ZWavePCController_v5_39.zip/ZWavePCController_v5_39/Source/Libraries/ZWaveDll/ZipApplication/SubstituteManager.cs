﻿using System;
using System.Collections.Generic;
using ZWave.Layers;
using ZWave.Layers.Frame;
using ZWave.ZipApplication.Operations;
using ZWave.Enums;

namespace ZWave.ZipApplication
{
    public class SubstituteManager : ISubstituteManager
    {
        public SubstituteIncomingFlags Id
        {
            get { return SubstituteIncomingFlags.None; }
        }

        private Func<byte, byte[], bool> mSendDataSubstitutionCallback;
        public Func<byte, byte[], bool> SendDataSubstitutionCallback
        {
            get
            {
                return mSendDataSubstitutionCallback;
            }
            internal set
            {
                mSendDataSubstitutionCallback = value;
            }
        }

        private Action<byte, byte[], bool> mReceiveDataSubstitutionCallback;
        public Action<byte, byte[], bool> ReceiveDataSubstitutionCallback
        {
            get
            {
                return mReceiveDataSubstitutionCallback;
            }
            internal set
            {
                mReceiveDataSubstitutionCallback = value;
            }
        }

        public SubstituteManager(Func<byte, byte[], bool> sendDataSubstitutionCallback, Action<byte, byte[], bool> receiveDataSubstitutionCallback)
        {
            SendDataSubstitutionCallback = sendDataSubstitutionCallback;
            ReceiveDataSubstitutionCallback = receiveDataSubstitutionCallback;
        }

        public void OnIncomingSubstituted(CustomDataFrame dataFrameOri, CustomDataFrame dataFrameSub, List<ActionHandlerResult> ahResults)
        {

        }

        public CustomDataFrame SubstituteIncoming(CustomDataFrame packet, out ActionBase additionalAction /*Optional*/, out ActionBase completeAction /*Optional*/)
        {
            additionalAction = null;
            completeAction = null;
            CustomDataFrame ret = packet;
            if (packet != null && packet.Payload != null && packet.Payload.Length > 1)
            {
                if (ReceiveDataSubstitutionCallback != null)
                {
                    ReceiveDataSubstitutionCallback(0, packet.Payload, false);
                }
            }
            return ret;
        }

        public ActionBase SubstituteAction(ActionBase action)
        {
            ActionBase ret = null;
            byte[] data = null;
            if (action is SendDataOperation)
                data = ((SendDataOperation)action).Data;
            else if (action is RequestDataOperation)
                data = ((RequestDataOperation)action).Data;
            if (data != null && SendDataSubstitutionCallback != null)
                SendDataSubstitutionCallback(0, data);
            return ret;
        }

        public void SetDefault()
        {
        }

        public void SetNodeId(byte nodeId)
        {
        }

        public void SetHomeId(byte[] homeId)
        {
        }

        public List<ActionToken> GetRunningActionTokens()
        {
            throw new NotImplementedException();
        }

        public void AddRunningActionToken(ActionToken token)
        {
            throw new NotImplementedException();
        }

        public void RemoveRunningActionToken(ActionToken token)
        {
            throw new NotImplementedException();
        }

        public void Suspend()
        {
            IsActive = false;
        }

        public void Resume()
        {
            IsActive = true;
        }

        public bool IsActive { get; private set; }
    }
}
