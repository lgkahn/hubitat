﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Utils;
using ZWave.CommandClasses;
using ZWave.Layers;
using ZWave.Layers.Transport;

namespace ZWave.ZipApplication
{
    public class ZipControllerDiscoverService : IDisposable
    {
        const int LOCAL_PORT = 51230; // Any port we choose.
        const int DISCOVER_TIMEOUT = 5000;
        HashSet<string> _zipControllerIps = new HashSet<string>();
        private IPAddress _ipv4RemoteAddress = null;
        private IPAddress _ipv6RemoteAddress = null;
        private int _port;

        public ZipControllerDiscoverService(string ipv6Address, string ipv4Address, int port)
        {
            _port = port;
            if (!string.IsNullOrEmpty(ipv4Address))
                IPAddress.TryParse(ipv4Address, out _ipv4RemoteAddress);
            if (!string.IsNullOrEmpty(ipv6Address))
                IPAddress.TryParse(ipv6Address, out _ipv6RemoteAddress);
        }

        public string[] Discover(IPAddress localEndpointAddress, bool useIPv6)
        {
            _zipControllerIps.Clear();
            try
            {
                var hostName = Dns.GetHostName();
                var ipEntry = Dns.GetHostEntry(hostName);

                var localIps = new List<IPAddress>();
                if (_ipv6RemoteAddress != null && useIPv6)
                {
                    if (localEndpointAddress != null)
                    {
                        localIps.AddRange(ipEntry.AddressList.Where(address => IPAddress.Equals(address, localEndpointAddress) && address.AddressFamily == AddressFamily.InterNetworkV6));
                    }
                    else
                    {
                        localIps.AddRange(ipEntry.AddressList.Where(address => address.AddressFamily == AddressFamily.InterNetworkV6));
                    }
                }
                if (_ipv4RemoteAddress != null && !useIPv6)
                {
                    if (localEndpointAddress != null)
                    {
                        localIps.AddRange(ipEntry.AddressList.Where(address => IPAddress.Equals(address, localEndpointAddress) && address.AddressFamily == AddressFamily.InterNetwork));
                    }
                    else
                    {
                        localIps.AddRange(ipEntry.AddressList.Where(address => address.AddressFamily == AddressFamily.InterNetwork));
                    }
                }

                List<UdpClientTransportListener> startedListeners = new List<UdpClientTransportListener>();
                foreach (var localIp in localIps)
                {
                    // Start udp listener.
                    UdpClientTransportListener udpListener = new UdpClientTransportListener();
                    startedListeners.Add(udpListener);
                    udpListener.DataReceived += ZipGatewayListener_DataReceived;
                    udpListener.Listen(new StartListenParams
                    {
                        IpAddress = localIp,
                        PortNo = (ushort)LOCAL_PORT
                    });
                    var remoteIp = localIp.AddressFamily == AddressFamily.InterNetworkV6 ? _ipv6RemoteAddress : _ipv4RemoteAddress;
                    DiscoverByLocalEnpoint(new IPEndPoint(localIp, LOCAL_PORT), new IPEndPoint(remoteIp, _port), udpListener);
                }
                Thread.Sleep(1000);
                foreach (var udpListener in startedListeners)
                {
                    udpListener.DataReceived -= ZipGatewayListener_DataReceived;
                    udpListener.Close();
                }
            }
            catch (SocketException ex)
            {
                ex.Message._EXLOG();
            }

            return _zipControllerIps.ToArray();
        }

        public string[] Discover(ZipApplicationLayer applicationLayer, IPAddress localEndpointAddress, bool useIPv6)
        {
            if (applicationLayer == null)
                throw new ArgumentNullException("applicationLayer");

            string[] result = Discover(localEndpointAddress, useIPv6);
            return result;
        }

        private void DiscoverByLocalEnpoint(IPEndPoint localEndPoint, IPEndPoint remoteEndPoint, UdpClientTransportListener zipGatewayListener)
        {
            // Create udp client for broadcast request.
            using (var discoverUdpClient = new UdpClient(localEndPoint.AddressFamily))
            {
                // Bind client to local address.
                discoverUdpClient.ExclusiveAddressUse = false;
                discoverUdpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                discoverUdpClient.Client.Bind(localEndPoint);

                // Compose Node Info Cached Get request.
                var zipPacket = new COMMAND_CLASS_ZIP_V2.COMMAND_ZIP_PACKET();
                zipPacket.zWaveCommand = new List<byte>((byte[])new COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_GET());
                zipPacket.properties2.zWaveCmdIncluded = 1;
                zipPacket.properties2.secureOrigin = 1;
                zipPacket.seqNo = 1;

                // Send breadcast data.
                discoverUdpClient.Send(zipPacket, ((byte[])zipPacket).Length, remoteEndPoint);
                discoverUdpClient.Close();
            }
        }

        private void ZipGatewayListener_DataReceived(ReceivedDataArgs obj)
        {
            if (obj.Data[0] == COMMAND_CLASS_ZIP_V2.ID && obj.Data[1] == COMMAND_CLASS_ZIP_V2.VERSION)
            {
                var zipPacket = (COMMAND_CLASS_ZIP_V2.COMMAND_ZIP_PACKET)obj.Data;
                if (zipPacket.zWaveCommand.Count > 0)
                {
                    var zCommand = zipPacket.zWaveCommand.ToArray();
                    if ((zCommand[0] == COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.ID &&
                        zCommand[1] == COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_REPORT.ID) ||
                        (zCommand[0] == COMMAND_CLASS_APPLICATION_STATUS.ID &&
                        zCommand[1] == COMMAND_CLASS_APPLICATION_STATUS.APPLICATION_BUSY.ID))
                    {
                        lock (_zipControllerIps)
                        {
                            if (!string.IsNullOrEmpty(obj.SourceName) && !_zipControllerIps.Contains(obj.SourceName))
                            {
                                _zipControllerIps.Add(obj.SourceName);
                            }
                        }
                    }
                }
            }
        }

        public void Dispose()
        {
        
        }
    }
}
