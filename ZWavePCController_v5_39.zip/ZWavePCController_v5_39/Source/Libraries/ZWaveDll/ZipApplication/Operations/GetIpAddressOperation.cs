﻿using System;
using System.Linq;
using System.Net;
using ZWave.CommandClasses;

namespace ZWave.ZipApplication.Operations
{
    public class GetIpAddressOperation : RequestDataOperation
    {
        private byte NodeId { get; set; }
        public GetIpAddressOperation(byte nodeId)
            : base(null, null, COMMAND_CLASS_ZIP_ND.ID, COMMAND_CLASS_ZIP_ND.ZIP_NODE_ADVERTISEMENT.ID, 2000)
        {
            NodeId = nodeId;
            Data = new COMMAND_CLASS_ZIP_ND.ZIP_INV_NODE_SOLICITATION() { nodeId = NodeId };
            IsNoAck = true;
        }

        protected override void OnReceived(DataReceivedUnit ou)
        {
            COMMAND_CLASS_ZIP_ND.ZIP_NODE_ADVERTISEMENT packet = (COMMAND_CLASS_ZIP_ND.ZIP_NODE_ADVERTISEMENT)ou.DataFrame.Payload;
            SpecificResult.NodeId = packet.nodeId;
            SpecificResult.HomeId = packet.homeId.ToArray();
            SpecificResult.IpAddress = GetIpAddressBytes(packet.ipv6Address.ToArray());
            base.SetStateCompleted(ou);
        }

        private static IPAddress GetIpAddressBytes(byte[] ipAddress)
        {
            byte[] ipAddr = ipAddress;

            if (ipAddress[0] == 0 &&
                ipAddress[1] == 0 &&
                ipAddress[2] == 0 &&
                ipAddress[3] == 0 &&
                ipAddress[4] == 0 &&
                ipAddress[5] == 0 &&
                ipAddress[6] == 0 &&
                ipAddress[7] == 0 &&
                ipAddress[8] == 0 &&
                ipAddress[9] == 0 &&
                ipAddress[10] == 0xFF &&
                ipAddress[11] == 0xFF)
            {
                ipAddr = new byte[4];
                Array.Copy(ipAddress, 12, ipAddr, 0, 4);
            }
            return new IPAddress(ipAddr);
        }

        public override string AboutMe()
        {
            return string.Format("IP={0}", SpecificResult.IpAddress == null ? "" : SpecificResult.IpAddress.ToString());
        }

        public new GetIpAddressResult SpecificResult
        {
            get { return (GetIpAddressResult)Result; }
        }

        protected override ActionResult CreateOperationResult()
        {
            return new GetIpAddressResult();
        }
    }

    public class GetIpAddressResult : ActionResult
    {
        public byte NodeId { get; set; }
        public byte[] HomeId { get; set; }
        public IPAddress IpAddress { get; set; }
    }
}
