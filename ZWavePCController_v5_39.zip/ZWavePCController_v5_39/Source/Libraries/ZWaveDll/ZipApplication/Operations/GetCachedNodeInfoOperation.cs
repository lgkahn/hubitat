﻿using System.Collections.Generic;
using ZWave.CommandClasses;
using System.Linq;
using ZWave.Xml.Application;
using ZWave.Devices;
using ZWave.Enums;

namespace ZWave.ZipApplication.Operations
{
    public class GetCachedNodeInfoOperation : RequestDataOperation
    {
        private byte NodeId { get; set; }
        public GetCachedNodeInfoOperation(byte nodeId, int timeoutMs)
            : base(null, null,
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.ID,
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_REPORT.ID,
            timeoutMs)
        {
            NodeId = nodeId;
            Data = new COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_GET()
            {
                nodeId = NodeId,
                seqNo = SequenceNumber
            };
        }

        protected override void OnReceived(DataReceivedUnit ou)
        {
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_REPORT packet = (COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_INFO_CACHED_REPORT)ou.DataFrame.Payload;
            SpecificResult.NodeId = NodeId;
            SpecificResult.NodeInfo = new NodeInfo
            {
                Basic = packet.basicDeviceClass,
                Generic = packet.genericDeviceClass,
                Properties1 = packet.properties1,
                Capability = packet.properties2,
                Security = packet.properties3,
                Specific = packet.specificDeviceClass
            };
            var grantedKeys = (NetworkKeyS2Flags)packet.grantedKeys;
            List<SecuritySchemes> securitySchemes = new List<SecuritySchemes>();
            if (grantedKeys.HasFlag(NetworkKeyS2Flags.S2Class2))
            {
                securitySchemes.Add(SecuritySchemes.S2_ACCESS);
            }
            if (grantedKeys.HasFlag(NetworkKeyS2Flags.S2Class1))
            {
                securitySchemes.Add(SecuritySchemes.S2_AUTHENTICATED);
            }
            if (grantedKeys.HasFlag(NetworkKeyS2Flags.S2Class0))
            {
                securitySchemes.Add(SecuritySchemes.S2_UNAUTHENTICATED);
            }
            if (grantedKeys.HasFlag(NetworkKeyS2Flags.S0))
            {
                securitySchemes.Add(SecuritySchemes.S0);
            }
            SpecificResult.SecuritySchemes = securitySchemes.ToArray();
            if (packet.commandClass != null)
            {
                byte[] commandClasses = null;
                byte[] secureCommandClasses = null;
                ZWaveDefinition.TryParseCommandClassRef(packet.commandClass, out commandClasses, out secureCommandClasses);
                SpecificResult.CommandClasses = commandClasses;
                SpecificResult.SecureCommandClasses = secureCommandClasses;
            }
            base.SetStateCompleted(ou);
        }

        public new GetCachedNodeInfoResult SpecificResult
        {
            get { return (GetCachedNodeInfoResult)Result; }
        }

        protected override ActionResult CreateOperationResult()
        {
            return new GetCachedNodeInfoResult();
        }
    }

    public class GetCachedNodeInfoResult : RequestDataResult
    {
        public byte NodeId { get; set; }
        public NodeInfo NodeInfo { get; set; }
        public byte[] CommandClasses { get; set; }
        public byte[] SecureCommandClasses { get; set; }
        public SecuritySchemes[] SecuritySchemes { get; set; }
    }
}
