﻿using ZWave.CommandClasses;
using ZWave.Enums;

namespace ZWave.ZipApplication.Operations
{
    public class RemoveNodeOperation : RequestDataOperation
    {
        private Modes Mode { get; set; }
        public RemoveNodeOperation(Modes mode, int timeoutMs)
            : base(null, null,
            COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.ID,
            COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.NODE_REMOVE_STATUS.ID,
            timeoutMs)
        {
            Mode = mode;
            Data = new COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.NODE_REMOVE()
            {
                mode = (byte)Mode,
                seqNo = SequenceNumber
            };
        }

        protected ZipApiMessage messageStop;
        protected override void CreateInstance()
        {
            base.CreateInstance();
            messageStop = new ZipApiMessage(_headerExtension, new COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.NODE_REMOVE()
            {
                mode = (byte)Modes.NodeStop,
                seqNo = SequenceNumber
            });
            messageStop.SetSequenceNumber(SequenceNumber);
            ActionUnitStop = new ActionUnit(messageStop);
        }

        protected override void OnReceived(DataReceivedUnit ou)
        {
            COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.NODE_REMOVE_STATUS packet = (COMMAND_CLASS_NETWORK_MANAGEMENT_INCLUSION_V3.NODE_REMOVE_STATUS)ou.DataFrame.Payload;
            SpecificResult.NodeId = packet.nodeid;
            SpecificResult.Status = packet.status;

            SetStateCompleted(ou);
        }

        public override string AboutMe()
        {
            return string.Format("Id={0}, Status={1}", SpecificResult.NodeId, SpecificResult.Status);
        }

        public new RemoveNodeResult SpecificResult
        {
            get { return (RemoveNodeResult)Result; }
        }

        protected override ActionResult CreateOperationResult()
        {
            return new RemoveNodeResult();
        }
    }

    public class RemoveNodeResult : RequestDataResult
    {
        public byte NodeId { get; set; }
        public byte Status { get; set; }
    }
}
