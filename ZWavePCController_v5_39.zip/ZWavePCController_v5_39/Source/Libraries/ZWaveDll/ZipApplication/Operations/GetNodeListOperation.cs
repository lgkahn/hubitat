﻿using System.Collections.Generic;
using ZWave.CommandClasses;

namespace ZWave.ZipApplication.Operations
{
    public class GetNodeListOperation : RequestDataOperation
    {
        public GetNodeListOperation(int timeoutMs)
            : base(null, null,
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.ID,
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_REPORT.ID,
            timeoutMs)
        {
            Data = new COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_GET()
            {
                seqNo = SequenceNumber
            };
        }

        protected override void OnReceived(DataReceivedUnit ou)
        {
            COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_REPORT packet = (COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_REPORT)ou.DataFrame.Payload;
            SpecificResult.ControllerId = packet.nodeListControllerId;
            List<byte> nodes = new List<byte>();
            if (packet.nodeListData != null)
            {
                for (int i = 0; i < packet.nodeListData.Count; i++)
                {

                    byte maskByte = packet.nodeListData[i];
                    if (maskByte == 0)
                    {
                        continue;
                    }
                    byte bitMask = 0x01;
                    byte bitOffset = 0x01;//nodes starting from 1 in mask bytes array
                    for (int j = 0; j < 8; j++)
                    {
                        if ((bitMask & maskByte) != 0)
                        {
                            byte nodeID = (byte)(((i * 8) + j) + bitOffset);
                            nodes.Add(nodeID);
                        }
                        bitMask <<= 1;
                    }
                }
            }
            SpecificResult.Nodes = nodes.ToArray();
            SpecificResult.Status = packet.status;

            SetStateCompleted(ou);
        }

        public new GetNodeListResult SpecificResult
        {
            get { return (GetNodeListResult)Result; }
        }

        protected override ActionResult CreateOperationResult()
        {
            return new GetNodeListResult();
        }
    }

    public class GetNodeListResult : RequestDataResult
    {
        public byte ControllerId { get; set; }
        public byte[] Nodes { get; set; }
        public byte Status { get; set; }
    }
}
