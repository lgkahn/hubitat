﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZWave.Enums;
using ZWave.ZipApplication.Data;

namespace ZWave.ZipApplication
{
    public class ZipApiMessage : CommandMessage
    {
        public byte[] HeaderExtension { get; set; }
        public ZipApiMessage(byte[] headerExtension, byte[] data)
        {
            HeaderExtension = headerExtension;
            AddData(data);
        }
    }
}
