﻿using System;
using System.Net;
using System.Threading;
using ZWave.Layers;
using Utils;

namespace ZWave.ZipApplication
{
    public class Dtls1ClientTransportListener : ITransportListener
    {
        private bool _disposed = false;
        private object _listenerLock = new object();
        public ushort PortNo;

        public event Action<ReceivedDataArgs> DataReceived;

        public event Action<string, ushort> ConnectionCreated;
        public event Action<string, ushort> ConnectionClosed;

        public bool SuppressDebugOutput { get; set; }
        private IDtlsListener _listener;
        public IDtlsListener Listener
        {
            get { return _listener ?? (_listener = new DtlsListener()); }
            set { _listener = value; }
        }

        public bool IsListening { get { return Listener.Listening; } }

        public bool Listen(IStartListenParams listenParams)
        {
            lock (_listenerLock)
            {
                if (!Listener.Listening)
                {
                    var dtlsListenParams = listenParams as IDtlsStartListenParams;
                    if (dtlsListenParams == null)
                    {
                        throw new ArgumentException("Invalid listenParams.");
                    }

                    if (dtlsListenParams.PortNo == 0)
                    {
                        throw new ArgumentException("Zero port number.");
                    }

                    if (string.IsNullOrEmpty(dtlsListenParams.PskKey))
                    {
                        throw new ArgumentException("PSK key can't be null or empty.");
                    }
                    PortNo = dtlsListenParams.PortNo;
                    "DTLSv1 Listening started @{0}"._DLOG(PortNo);
                    Listener.ClientConnected += Listener_ConnectionCreated;
                    Listener.ClientClosed += Listener_ConnectionClosed;
                    Listener.DataReceived += Listener_DataReceived;
                    var retCode = Listener.Start(dtlsListenParams.PskKey, PortNo);
                    if (retCode != 0)
                    {
                        "DTLSv1 Listening failed @{0} Error code: {1}"._DLOG(PortNo, retCode.ToString());
                        Listener.ClientConnected -= Listener_ConnectionCreated;
                        Listener.ClientClosed -= Listener_ConnectionClosed;
                        Listener.DataReceived -= Listener_DataReceived;
                    }
                    else
                    {
                        _disposed = false;
                    }
                }
            }
            return IsListening;
        }

        void Listener_ConnectionCreated(string address, ushort portNo)
        {
            if (ConnectionCreated != null)
            {
                ConnectionCreated(address, portNo);
            }
        }

        void Listener_ConnectionClosed(string address, ushort portNo)
        {
            if (ConnectionClosed != null)
            {
                ConnectionClosed(address, portNo);
            }
        }

        public void Close()
        {
            lock (_listenerLock)
            {
                if (Listener.Listening)
                {
                    Listener.ClientConnected -= Listener_ConnectionCreated;
                    Listener.ClientClosed -= Listener_ConnectionClosed;
                    Listener.DataReceived -= Listener_DataReceived;
                    Listener.Stop();
                    "DTLSv1 Listening stoped @{0}"._DLOG(PortNo);
                }
            }
        }

        private void Listener_DataReceived(byte[] bytes, string sourceName, ushort sourcePortNo)
        {
            if (!SuppressDebugOutput)
            {
                "Listener accepted {0} >> {1}"._DLOG(sourceName, Tools.GetHex(bytes));
            }
            if (DataReceived != null)
            {
                DataReceived(new ReceivedDataArgs { Data = bytes, SourceName = sourceName, SourcePort = sourcePortNo, ListenerPort = PortNo });
            }
        }

        public int ResponseTo(byte[] data, string address, ushort portNo)
        {
            if (!SuppressDebugOutput)
            {
                "{0}:{1} >> {2}"._DLOG(address, portNo.ToString(), Tools.GetHex(data));
            }
            return Listener.ResponseTo(data, address, portNo);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            // Protect from being called multiple times.
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                // Clean up all managed resources.
            }

            // Clean up all unmanaged resources.
            if (Listener != null)
            {
                Close();
            }

            _disposed = true;
        }

        ~Dtls1ClientTransportListener()
        {
            Dispose(false);
        }
    }

    public class Dtls1StartListenParams : IDtlsStartListenParams
    {
        public IPAddress IpAddress { get; set; }
        public ushort PortNo { get; set; }
        public string PskKey { get; set; }
    }
}
