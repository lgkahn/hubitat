﻿namespace ZWave.ZipApplication
{
    public abstract class ZipApiOperation : ActionBase
    {
        protected int AckTimeout = 66000;
        protected byte[] _headerExtension;
        public ZipApiOperation(bool isExclusive)
            : base(isExclusive)
        {
            IsSequenceNumberRequired = true;
        }
    }
}
