﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZWave.Layers;
using ZWave.Layers.Transport;
using ZWave.ZipApplication.Devices;
using ZWave.Layers.Application;
using ZWave.Enums;

namespace ZWave.ZipApplication
{
    public class ZipApplicationLayer : ApplicationLayer
    {
        public ZipApplicationLayer(ISessionLayer sessionLayer, IFrameLayer frameLayer, ITransportLayer transportLayer)
            : base(ApiTypes.Zip, sessionLayer, frameLayer, transportLayer)
        {
        }

        public ZipDevice CreateZipDevice()
        {
            var sessionId = NextSessionId();
            ZipDevice ret = new ZipDevice(sessionId, SessionLayer.CreateClient(), FrameLayer.CreateClient(), TransportLayer.CreateClient(sessionId));
            return ret;
        }

        public ZipController CreateZipController()
        {
            var sessionId = NextSessionId();
            ZipController ret = new ZipController(sessionId, SessionLayer.CreateClient(), FrameLayer.CreateClient(), TransportLayer.CreateClient(sessionId));
            return ret;
        }

        public ITransportListener CreateZipUpdListener()
        {
            var ret = new UdpClientTransportListener();
            return ret;
        }
    }
}
