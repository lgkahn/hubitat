﻿using System;
using System.Collections.Generic;
using System.Linq;
using Utils;
using ZWave.CommandClasses;
using ZWave.ZipApplication.Operations;

namespace ZWave.ZipApplication.CommandClasses
{
    public class NetworkManagementProxySupport : ResponseDataOperation
    {
        byte[] _commandsToSupport;
        Action<GetNodeListResult> _updateControllerCallback;


        public NetworkManagementProxySupport(byte[] commandsToSupport, Action<GetNodeListResult> updateControllerCallback)
            : base(COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.ID)
        {
            ReceiveCallback = OnReceiveCallback;
            _commandsToSupport = commandsToSupport;
            _updateControllerCallback = updateControllerCallback;
            _isHeaderExtensionSpecified = true;
        }

        public byte[] OnReceiveCallback(byte[] headerExtension, byte[] payload)
        {
            byte[] ret = null;
            if (payload != null && payload.Length > 2)
            {
                if (payload[1] == COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_REPORT.ID && _commandsToSupport.Contains(payload[1]))
                {
                    var packet = (COMMAND_CLASS_NETWORK_MANAGEMENT_PROXY_V2.NODE_LIST_REPORT)payload;
                    var result = new GetNodeListResult();
                    result.ControllerId = packet.nodeListControllerId;
                    List<byte> nodes = GetNodes(packet.nodeListData);

                    result.Nodes = nodes.ToArray();
                    result.Status = packet.status;

                    if (_updateControllerCallback != null)
                        _updateControllerCallback(result);
                }
            }
            return ret;
        }

        private List<byte> GetNodes(IList<byte> nodeListData)
        {
            List<byte> nodes = new List<byte>();
            if (nodeListData != null)
            {
                for (int i = 0; i < nodeListData.Count; i++)
                {

                    byte maskByte = nodeListData[i];
                    if (maskByte == 0)
                    {
                        continue;
                    }
                    byte bitMask = 0x01;
                    byte bitOffset = 0x01;//nodes starting from 1 in mask bytes array
                    for (int j = 0; j < 8; j++)
                    {
                        if ((bitMask & maskByte) != 0)
                        {
                            byte nodeID = (byte)(((i * 8) + j) + bitOffset);
                            nodes.Add(nodeID);
                        }
                        bitMask <<= 1;
                    }
                }
            }
            return nodes;
        }
    }
}
