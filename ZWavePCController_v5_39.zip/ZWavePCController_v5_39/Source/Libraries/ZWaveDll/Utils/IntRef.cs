﻿namespace Utils
{
    public class IntRef
    {
        public int Value { get; set; }
        public IntRef(int value)
        {
            Value = value;
        }
    }
}
