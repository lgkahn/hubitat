﻿namespace Utils.UI.MVVM
{
    public class OpenFileDialogViewModel : DialogVMBase
    {
        public string FileName { get; set; }
        public string Filter { get; set; }
    }
}
