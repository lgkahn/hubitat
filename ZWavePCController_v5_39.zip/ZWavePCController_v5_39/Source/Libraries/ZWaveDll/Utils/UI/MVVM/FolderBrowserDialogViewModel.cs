﻿namespace Utils.UI.MVVM
{
    public class FolderBrowserDialogViewModel : DialogVMBase
    {
        public string FolderPath { get; set; }
    }
}
