﻿namespace Utils.UI.MVVM
{
    public class SaveFileDialogViewModel : DialogVMBase
    {
        public string FileName { get; set; }
        public string Filter { get; set; }
    }
}
