﻿namespace Utils.UI.Wrappers
{
    public interface ISelectable
    {
        bool IsSelected { get; set; }
    }
}