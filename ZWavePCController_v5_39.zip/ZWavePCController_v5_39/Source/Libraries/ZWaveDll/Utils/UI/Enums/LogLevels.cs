﻿namespace Utils.UI.Enums
{
    public enum LogLevels
    {
        Title,
        Text,
        Done,
        Ok,
        Fail,
        Warning,
        Trace,
        Information,
        Error,
        ZnifferTrace,
        Diagnostic,
    }
}
