﻿namespace Utils.UI.Enums
{
    public enum LogIndents
    {
        None,
        Current,
        Increase,
        Decrease
    }
}
