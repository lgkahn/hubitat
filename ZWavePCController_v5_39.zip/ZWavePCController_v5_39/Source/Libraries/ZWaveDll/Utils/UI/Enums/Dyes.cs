﻿namespace Utils.UI.Enums
{
    public enum Dyes
    {
        Black,
        Gray,
        Blue,
        Green,
        Red,
        Yellow,
        DarkOrange,
        Orange
    }
}
