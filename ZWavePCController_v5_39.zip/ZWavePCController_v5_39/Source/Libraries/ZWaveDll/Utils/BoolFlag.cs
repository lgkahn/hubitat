﻿namespace Utils
{
    public enum BoolFlag
    {
        NotSpecified = 0,
        True = 1,
        False = 2
    }
}
