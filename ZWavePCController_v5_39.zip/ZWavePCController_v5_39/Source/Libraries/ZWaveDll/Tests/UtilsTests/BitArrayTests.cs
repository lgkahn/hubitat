﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Utils;

namespace UtilsTests
{
    [TestFixture]
    public class BitArrayTests
    {
        [Test]
        public void BitArray256_SetValueClearValue_GetValue()
        {
            BitArray256 array = new BitArray256();
            for (int i = 0; i < BitArray256.MaxCount; i++)
            {
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(1, array.GetValuesCount());

                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(0, array.GetValuesCount());
            }
        }

        [Test]
        public void BitArray256_AllSetSetValue_GetValue()
        {
            BitArray256 array = new BitArray256();
            for (int i = 0; i < BitArray256.MaxCount; i++)
            {
                array.SetAll(false);
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(1, array.GetValuesCount());

                array.SetAll(true);
                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(BitArray256.MaxCount - 1, array.GetValuesCount());
            }
        }

        [Test]
        public void BitArray256_SetValue_GetValue()
        {
            BitArray256 array = new BitArray256();
            for (int i = 0; i < BitArray256.MaxCount; i++)
            {
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(i + 1, array.GetValuesCount());
            }

            for (int i = 0; i < BitArray256.MaxCount; i++)
            {
                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(BitArray256.MaxCount - 1 - i, array.GetValuesCount());
            }
        }

        [Test]
        public void BitArray8_SetValueClearValue_GetValue()
        {
            BitArray8 array = new BitArray8();
            for (int i = 0; i < BitArray8.MaxCount; i++)
            {
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(1, array.GetValuesCount());

                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(0, array.GetValuesCount());
            }
        }

        [Test]
        public void BitArray8_AllSetSetValue_GetValue()
        {
            BitArray8 array = new BitArray8();
            for (int i = 0; i < BitArray8.MaxCount; i++)
            {
                array.SetAll(false);
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(1, array.GetValuesCount());

                array.SetAll(true);
                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(BitArray8.MaxCount - 1, array.GetValuesCount());
            }
        }

        [Test]
        public void BitArray8_SetValue_GetValue()
        {
            BitArray8 array = new BitArray8();
            for (int i = 0; i < BitArray8.MaxCount; i++)
            {
                array[i] = true;
                Assert.IsTrue(array[i]);
                Assert.AreEqual(i + 1, array.GetValuesCount());
            }

            for (int i = 0; i < BitArray8.MaxCount; i++)
            {
                array[i] = false;
                Assert.IsFalse(array[i]);
                Assert.AreEqual(BitArray8.MaxCount - 1 - i, array.GetValuesCount());
            }
        }
    }
}
