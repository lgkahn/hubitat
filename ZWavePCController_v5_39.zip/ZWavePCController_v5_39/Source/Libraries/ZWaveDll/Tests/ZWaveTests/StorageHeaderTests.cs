﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ZWave;

namespace ZWaveTests
{
    [TestFixture]
    public class StorageHeaderTests
    {
        [Test]
        public void Create_Default_VersionIs103()
        {
            StorageHeader sh = new StorageHeader();
            Assert.AreEqual(103, sh.Version);
            sh.UpdateSourceAndFrequensiesToBuffer();
            sh = new StorageHeader(sh.Buffer);
            Assert.IsTrue(sh.IsValid);
        }

        [Test]
        public void Create_ChangeTraceTotalLength_ValueStored()
        {
            StorageHeader sh = new StorageHeader();
            sh.TraceTotalLength = int.MaxValue;
            Assert.AreEqual(int.MaxValue, sh.TraceTotalLength);
            sh.TraceTotalLength = long.MaxValue;
            Assert.AreEqual(long.MaxValue, sh.TraceTotalLength);
            sh.TraceTotalLength = -1;
            Assert.AreEqual(ulong.MaxValue, (ulong)sh.TraceTotalLength);
            sh.UpdateSourceAndFrequensiesToBuffer();
            Assert.IsTrue(sh.IsValid);
            sh = new StorageHeader(sh.Buffer);
            Assert.IsTrue(sh.IsValid);
        }

        [Test]
        public void Create_ChangeSessions_ValueStored()
        {
            StorageHeader sh = new StorageHeader();
            sh.Sessions.Add(0x01, "COM1");
            sh.Sessions.Add(0x21, "COM21");
            sh.UpdateSourceAndFrequensiesToBuffer();
            Assert.IsTrue(sh.IsValid);
            sh = new StorageHeader(sh.Buffer);
            Assert.IsTrue(sh.IsValid);
            Assert.AreEqual(2, sh.Sessions.Count);
            Assert.AreEqual("COM1", sh.Sessions[0x01]);
            Assert.AreEqual("COM21", sh.Sessions[0x21]);
        }

        [Test]
        public void Create_ChangeFrequencies_ValueStored()
        {
            StorageHeader sh = new StorageHeader();
            sh.Frequencies.Add(0x01, new RFrequency(3, "EU"));
            sh.Frequencies.Add(0x21, new RFrequency(2, "US"));
            sh.UpdateSourceAndFrequensiesToBuffer();
            Assert.IsTrue(sh.IsValid);
            sh = new StorageHeader(sh.Buffer);
            Assert.IsTrue(sh.IsValid);
            Assert.AreEqual(2, sh.Frequencies.Count);
            Assert.AreEqual(3, sh.Frequencies[0x01].Channels);
            Assert.AreEqual(2, sh.Frequencies[0x21].Channels);
            Assert.AreEqual("EU", sh.Frequencies[0x01].Name);
            Assert.AreEqual("US", sh.Frequencies[0x21].Name);
        }

        [Test]
        public void Create_ChangeSessionsAndFrequencies_ValueStored()
        {
            StorageHeader sh = new StorageHeader();
            sh.Frequencies.Add(0x01, new RFrequency(3, "EU"));
            sh.Frequencies.Add(0x21, new RFrequency(2, "US"));
            sh.Sessions.Add(0x01, "COM1");
            sh.Sessions.Add(0x21, "COM21");
            sh.UpdateSourceAndFrequensiesToBuffer();
            Assert.IsTrue(sh.IsValid);
            sh = new StorageHeader(sh.Buffer);
            Assert.IsTrue(sh.IsValid);
            Assert.AreEqual(2, sh.Sessions.Count);
            Assert.AreEqual("COM1", sh.Sessions[0x01]);
            Assert.AreEqual("COM21", sh.Sessions[0x21]);
            Assert.AreEqual(2, sh.Frequencies.Count);
            Assert.AreEqual(3, sh.Frequencies[0x01].Channels);
            Assert.AreEqual(2, sh.Frequencies[0x21].Channels);
            Assert.AreEqual("EU", sh.Frequencies[0x01].Name);
            Assert.AreEqual("US", sh.Frequencies[0x21].Name);
        }
    }
}
