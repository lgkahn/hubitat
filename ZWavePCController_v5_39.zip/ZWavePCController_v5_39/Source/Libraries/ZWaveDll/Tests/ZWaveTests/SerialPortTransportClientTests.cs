﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using NSubstitute;
using ZWave.Layers;
using ZWave.Layers.Transport;
using ZWave.Enums;

namespace ZWaveTests
{
    [TestFixture]
    public class SerialPortTransportClientTests
    {
        private ITransportClient _serialPortTransportClient;
        private byte[] _data = new byte[] { 0x0, 0x1, 0x2 };
        private const int _sessionId = 0x79;
        private const ApiTypes _apiType = ApiTypes.Basic;
        private DataChunk _transmitedDataChunk;
        private DataChunk _receivedDataChunk;

        [SetUp]
        public void SetUp()
        {
            _serialPortTransportClient = new SerialPortTransportClient(OnDataTransmited)
            {
                DataSource = new SerialPortDataSource
                {
                    SourceName = "COM1"
                },
                SessionId = _sessionId,
                ApiType = _apiType
            };
            _transmitedDataChunk = null;
            _receivedDataChunk = null;
        }

        [TearDown]
        public void TearDown()
        {
            _serialPortTransportClient.Dispose();
        }

        [Test]
        public void Connect_ConnectionFailed_CommunicationStatusIsBusy()
        {
            // Arrange.
            var serialPortProviderStub = Substitute.For<ISerialPortProvider>();
            serialPortProviderStub.
                Open(Arg.Any<string>(), Arg.Any<int>(), Arg.Any<PInvokeParity>(), Arg.Any<int>(), Arg.Any<PInvokeStopBits>()).
                Returns(false);

            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderStub;

            // Act.
            var status = _serialPortTransportClient.Connect();

            // Assert.
            Assert.AreEqual(CommunicationStatuses.Busy, status);
        }

        [Test]
        public void Connect_BeforeConnectionEstablished_SerialPortCloseCalled()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;
            
            // Act.
            _serialPortTransportClient.Connect();

            // Assert.
            serialPortProviderMock.Received(1).Close();
        }

        [Test]
        public void Connect_SerialPortConnectedSuccessfuly_CommunicationStatusIsDone()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            serialPortProviderMock.Open(null, 0, PInvokeParity.None, 0, PInvokeStopBits.One).ReturnsForAnyArgs(true);
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;

            // Act.
            var status = _serialPortTransportClient.Connect();

            // Assert.
            Assert.AreEqual(CommunicationStatuses.Done, status);
        }

        [Test]
        public void Disconnect_CommunicationStatusIsFailed_SerialPortDoesntCallClose()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;

            // Act.
            _serialPortTransportClient.Disconnect();

            // Assert.
            serialPortProviderMock.DidNotReceive().Close();
        }

        [Test]
        public void Disconnect_CommunicationStatusIsDone_SerialPortCloseCalled()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            serialPortProviderMock.
                Open(null, 0, PInvokeParity.None, 0, PInvokeStopBits.One).
                ReturnsForAnyArgs(true);
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;

            // Act.
            _serialPortTransportClient.Connect();
            _serialPortTransportClient.Disconnect();

            // Assert.
            serialPortProviderMock.Received(1).Close();
        }

        [Test]
        public void WriteData_CommunicationStatusDoesntMatter_SerialPortProviderWriteDataCalled()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            serialPortProviderMock.Write(null, 0).ReturnsForAnyArgs(-1);
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;

            // Act.
            var written = _serialPortTransportClient.WriteData(_data);

            // Assert.
            serialPortProviderMock.ReceivedWithAnyArgs().Write(null, 0);
            Assert.AreEqual(-1, written);
        }

        [Test]
        public void WriteData_CommunicationStatusDoesntMatter_CallDataTransmitedCallback()
        {
            // Arrange.
            var serialPortProviderStub = Substitute.For<ISerialPortProvider>();
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderStub;

            // Act.
            _serialPortTransportClient.WriteData(_data);

            // Assert.
            Assert.AreEqual(_sessionId, _transmitedDataChunk.SessionId);
            Assert.AreEqual(_apiType, _transmitedDataChunk.ApiType);
            Assert.AreEqual(_data.Length, _transmitedDataChunk.DataBufferLength);
            Assert.IsTrue(_data.SequenceEqual(_transmitedDataChunk.GetDataBuffer()));
        }

        [Test]
        public void ReadData_ReadFromSerialPortThreadStarted_ReadDataCalled()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            serialPortProviderMock.Read(null, 0).
                ReturnsForAnyArgs(_data.Length).
                AndDoes(callInfo =>
                    {
                        var buff = (byte[])callInfo[0];
                        Array.Copy(_data, buff, _data.Length);
                    });
            serialPortProviderMock.
                Open(null, 0, PInvokeParity.None, 0, PInvokeStopBits.One).
                ReturnsForAnyArgs(true);
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;
            _serialPortTransportClient.ReceiveDataCallback += OnDataReceived;

            // Act.
            var status = _serialPortTransportClient.Connect(); // Connected successfuly.
            Assert.AreEqual(CommunicationStatuses.Done, status);
            Thread.Sleep(100);
            _serialPortTransportClient.Disconnect();

            // Assert.
            Assert.AreEqual(_data.Length, _receivedDataChunk.DataBufferLength);
            Assert.AreEqual(_apiType, _receivedDataChunk.ApiType);
            Assert.AreEqual(_sessionId, _receivedDataChunk.SessionId);
            Assert.IsTrue(_data.SequenceEqual(_receivedDataChunk.GetDataBuffer()));
            _serialPortTransportClient.ReceiveDataCallback -= OnDataReceived;
        }

        [Test]
        public void ReadData_ReadFromSerialPortThreadStarted_DataTransmitedCallbackCalled()
        {
            // Arrange.
            var serialPortProviderMock = Substitute.For<ISerialPortProvider>();
            serialPortProviderMock.Read(null, 0).
                ReturnsForAnyArgs(_data.Length).
                AndDoes(callInfo =>
                {
                    var buff = (byte[])callInfo[0];
                    Array.Copy(_data, buff, _data.Length);
                });
            serialPortProviderMock.
                Open(null, 0, PInvokeParity.None, 0, PInvokeStopBits.One).
                ReturnsForAnyArgs(true);
            ((SerialPortTransportClient)_serialPortTransportClient).SerialPortProvider = serialPortProviderMock;

            // Act.
            var status = _serialPortTransportClient.Connect(); // Connected successfuly.
            Assert.AreEqual(CommunicationStatuses.Done, status);
            Thread.Sleep(100);
            _serialPortTransportClient.Disconnect();

            // Assert.
            Assert.AreEqual(_data.Length, _transmitedDataChunk.DataBufferLength);
            Assert.AreEqual(_apiType, _transmitedDataChunk.ApiType);
            Assert.AreEqual(_sessionId, _transmitedDataChunk.SessionId);
            Assert.IsTrue(_data.SequenceEqual(_transmitedDataChunk.GetDataBuffer()));
        }

        private void OnDataTransmited(DataChunk dataChunk)
        {
            _transmitedDataChunk = dataChunk;
        }

        private void OnDataReceived(DataChunk dataChunk, bool val)
        {
            _receivedDataChunk = dataChunk;
        }
    }
}
