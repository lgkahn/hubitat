﻿using System;
using NUnit.Framework;
using NSubstitute;
using ZWave.Layers;
using ZWave.Enums;

namespace ZWaveTests
{
    [TestFixture]
    public class ApplicationLayerTests
    {
        private const int MAX_SESSIONS = 0x7F;

        private const ApiTypes ApiType = ApiTypes.Basic;
        private FakeApplicationLayer _applicationLayer;

        [SetUp]
        public void SetUp()
        {
            _applicationLayer = new FakeApplicationLayer(ApiType,
                Substitute.For<ISessionLayer>(),
                Substitute.For<IFrameLayer>(),
                Substitute.For<ITransportLayer>()
                );
        }

        [Test]
        public void NextSessionId_IncrementsSessionId()
        {
            // Arrange.
            const int max = 10;

            // Act.
            byte sessionId = 0;
            for (int i = 0; i < max; i++)
            {
                sessionId = _applicationLayer.NextSessionId();
            }

            // Assert.
            Assert.AreEqual(max - 1, sessionId);
        }

        [Test]
        public void ResetSessionIdCounter_ResetsSessionIdToZero()
        {
            // Act.
            var rand = new Random();
            var count = rand.Next(1, 0x7F);
            byte sessionId = 0;
            for (int i = 0; i < count + 1; i++)
            {
                sessionId = _applicationLayer.NextSessionId();
            }
            Assert.IsTrue(sessionId > 0);

            _applicationLayer.ResetSessionIdCounter();
            sessionId = _applicationLayer.NextSessionId();

            // Assert.
            Assert.AreEqual(0, sessionId);
        }

        [Test]
        public void ReleaseSessionIdAndCallNextSessionId_ReturnsReleasedValue()
        {
            // Arrange.
            const int max = 10;
            const byte released = 5;

            // Act.
            for (int i = 0; i < max; i++)
            {
                _applicationLayer.NextSessionId();
            }

            _applicationLayer.ReleaseSessionId(released);
            var sessionId = _applicationLayer.NextSessionId();

            // Assert.
            Assert.AreEqual(released, sessionId);
        }

        [Test]
        public void CreateClient_EveryLayerCreatesCorrespondingClient()
        {
            // Act.
            var client = _applicationLayer.CreateClient();

            // Assert.
            _applicationLayer.SessionLayer.Received(1).CreateClient();
            _applicationLayer.FrameLayer.Received(1).CreateClient();
            _applicationLayer.TransportLayer.Received(1).CreateClient(Arg.Any<byte>());
        }

        [Test]
        public void CreateClient_CreatedClientHasNextFreeSessionId()
        {
            // Arrange.
            const int max = 10;
            const byte released = 5;

            // Act.
            for (int i = 0; i < max; i++)
            {
                _applicationLayer.NextSessionId();
            }
            _applicationLayer.ReleaseSessionId(released);
            var client = _applicationLayer.CreateClient();

            // Assert.
            Assert.AreEqual(released, client.SessionId);
        }

        [Test]
        public void CreateClient_CreatedClientHasCorrectApiType()
        {
            // Act.
            var client = _applicationLayer.CreateClient();

            // Assert.
            Assert.AreEqual(ApiType, client.ApiType);
        }
    }
}
