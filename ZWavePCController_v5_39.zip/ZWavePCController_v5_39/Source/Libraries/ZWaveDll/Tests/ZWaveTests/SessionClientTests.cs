﻿using System;
using System.Threading;
using System.Collections.Generic;
using NUnit.Framework;
using NSubstitute;
using ZWave;
using ZWave.Layers;
using ZWave.Layers.Session;
using ZWave.TextApplication.Operations;
using Utils.Threading;

namespace ZWaveTests
{
    [TestFixture(Ignore = "not verified")]
    public class SessionClientTests
    {
        private SessionClient _sessionClient;
        private ISubstituteManager _substituteManagerMock;

        [SetUp]
        public void SetUp()
        {
            _sessionClient = new SessionClient(ActionChangeCallback)
            {
                TimeoutManager = Substitute.For<ITimeoutManager>(),
                CallbackBufferBlock = Substitute.For<IConsumerQueue<IActionItem>>(),
                ActionCaseConsumer = Substitute.For<IConsumerQueue<IActionCase>>(),
                SuppressDebugOutput = true
            };
            _substituteManagerMock = Substitute.For<ISubstituteManager>();
            _substituteManagerMock.
                SubstituteAction(Arg.Any<ActionBase>()).
                ReturnsForAnyArgs(x => x.Arg<ActionBase>());
            _sessionClient.AddSubstituteManager(_substituteManagerMock, null);
        }

        [TearDown]
        public void TearDown()
        {
            _sessionClient.Dispose();
        }

        [Test]
        public void ExecuteAsync_NoNextOperations_CallTimerManager_AddToCallbackBufferBlock_TokenReady()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            _sessionClient.SendFramesCallback = ahResult =>
            {
                ahResult.NextFramesCompletedCallback(true);
                return true;
            };

            _sessionClient.TimeoutManager.
                When(timeoutManager =>
                {
                    timeoutManager.AddTimer(Arg.Any<ActionToken>());
                }).
                Do(actionToken =>
                {
                    var at = (ActionToken)actionToken[0];
                    _sessionClient.TokenExpired(at);
                });

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            Thread.Sleep(250);

            // Call timeout manager.
            _sessionClient.TimeoutManager.Received().AddTimer(fakeAction.Token);
            // Add action to CallbackBufferBlock.
            _sessionClient.CallbackBufferBlock.Received().Add(fakeAction);
            // Check action token state.
            Assert.IsTrue(fakeAction.Token.WaitCompletedSignal());
            Assert.AreEqual(ActionStates.Expired, fakeAction.Token.Result.State);
        }

        [Test]
        public void ExecuteAsync_WithNextOperations_CallTimerManager_AddToCallbackBufferBlock_TokenReady()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new FakeAction());

            _sessionClient.SendFramesCallback = ahResult =>
            {
                ahResult.NextFramesCompletedCallback(true);
                return true;
            };
            _sessionClient.TimeoutManager.
                When(tm =>
                    tm.AddTimer(Arg.Any<ActionToken>())).
                Do(token =>
                {
                    var at = (ActionToken)token[0];
                    at.SetExpired();
                    _sessionClient.TokenExpired(at);
                });

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            Thread.Sleep(250);

            // Call timeout manager.
            _sessionClient.TimeoutManager.Received().AddTimer(fakeAction.Token);
            // Add action to CallbackBufferBlock.
            _sessionClient.CallbackBufferBlock.Received().Add(fakeAction);
            // Check action token state.
            Assert.IsTrue(fakeAction.Token.WaitCompletedSignal());
            Assert.AreEqual(ActionStates.Expired, fakeAction.Token.Result.State);
        }

        [Test]
        public void ExecuteAsync_WithNextTimeIntervals_AddIntervalsToTimerManager()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 0,
                    new TimeInterval(0, 100),
                    new TimeInterval(1, 100),
                    new TimeInterval(3, 100));

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);

            // Assert.
            _sessionClient.TimeoutManager.
                Received(3).
                AddTimer(Arg.Any<TimeInterval>());
        }

        [Test]
        public void ExecuteAsync_WithNextFramesHasNextTimeIntervals_AddIntervalsToTimerManager()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 0,
                   new CommandMessage(),
                   new TimeInterval(1, 100),
                   new TimeInterval(3, 100));

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);

            // Assert.
            _sessionClient.TimeoutManager.
                Received(2).
                AddTimer(Arg.Any<TimeInterval>());
        }

        [Test]
        public void ExecuteAsync_WithNextFrames_CallsSendFramesCallback()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            bool sendFramesCallbackCalled = false;
            _sessionClient.SendFramesCallback =
                ahResult => sendFramesCallbackCalled = true;

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);

            // Assert.
            Assert.IsTrue(sendFramesCallbackCalled);
        }

        [Test]
        public void ExecuteAsync_WithFramesNotTransmited_TokenHasFailedState()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            _sessionClient.SendFramesCallback =
                ahResult =>
                {
                    ahResult.NextFramesCompletedCallback(false);
                    return false;
                };

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);

            // Assert.
            Assert.AreEqual(ActionStates.Failed, fakeAction.Token.State);
        }

        [Test]
        public void ExecuteAsync_WithFramesIsTransmited_CallTimerManager_AddToCallbackBufferBlock_TokenReady()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            _sessionClient.SendFramesCallback =
                ahResult =>
                {
                    ahResult.NextFramesCompletedCallback(true);
                    return true;
                };

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);

            // Assert.
            // Call timeout manager.
            _sessionClient.TimeoutManager.Received().AddTimer(fakeAction.Token);
            // Add action to CallbackBufferBlock.
            _sessionClient.CallbackBufferBlock.Received().Add(fakeAction);
            // Check action token state.
            Assert.IsTrue(fakeAction.Token.WaitCompletedSignal());
        }

        [Test]
        public void Cancel_NoNextFrames_TokenIsCancelled_ActionRemovedFromRunning_AddToCallbackBufferBlock()
        {
            // Arrange.
            var fakeAction = new FakeAction();

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            Assert.AreEqual(1, _sessionClient.RunningActions.Count);
            _sessionClient.Cancel(fakeAction.Token);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeAction.Token.State);
            // Action removed from running actions.
            Assert.AreEqual(0, _sessionClient.RunningActions.Count);
            // Add action to CallbackBufferBlock.
            _sessionClient.CallbackBufferBlock.Received().Add(fakeAction);
            // Check action token state.
            Assert.IsTrue(fakeAction.Token.WaitCompletedSignal());
        }

        [Test]
        public void Cancel_WithParentAction_ParentActionsTokenIsCancelled_ChildActionsTokenIsCancelled()
        {
            // Arrange.
            var fakeParentAction = new FakeAction();
            var fakeAction = new FakeAction
            {
                ParentAction = fakeParentAction
            };

            // Act.
            _sessionClient.ExecuteAsync(fakeParentAction);
            _sessionClient.ExecuteAsync(fakeAction);
            Assert.AreEqual(2, _sessionClient.RunningActions.Count);
            _sessionClient.Cancel(fakeParentAction.Token);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeAction.Token.State);
            // Parent token state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeParentAction.Token.State);
            // Action removed from running actions.
            Assert.AreEqual(0, _sessionClient.RunningActions.Count);
        }

        [Test]
        public void Cancel_WithNextFrames_SendFramesCallbackCalled_TokenIsCancelled()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });
            var sendFramesCallbackCalled = false;
            _sessionClient.SendFramesCallback =
                ahResult =>
                {
                    sendFramesCallbackCalled = true;
                    ahResult.NextFramesCompletedCallback(true);
                    return true;
                };

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            _sessionClient.Cancel(fakeAction.Token);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeAction.Token.State);
            // SendFramesCallback called.
            Assert.IsTrue(sendFramesCallbackCalled);
        }

        [Test]
        public void Cancel_ByActionsTypes_SpecifiedActionsTokensAreCancelled()
        {
            // Arrange.
            var fakeAction1 = new FakeAction();
            var fakeAction2 = new FakeAction();
            var fakeAction3 = new FakeAction();
            var sendOp1 = new AnotherFakeAction();
            var sendOp2 = new AnotherFakeAction();

            // Act.
            _sessionClient.ExecuteAsync(fakeAction1);
            _sessionClient.ExecuteAsync(fakeAction2);
            _sessionClient.ExecuteAsync(fakeAction3);
            _sessionClient.ExecuteAsync(sendOp1);
            _sessionClient.ExecuteAsync(sendOp2);
            Assert.AreEqual(5, _sessionClient.RunningActions.Count);
            _sessionClient.Cancel(typeof(FakeAction));

            // Assert.
            // Tokens state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeAction1.Token.State);
            Assert.AreEqual(ActionStates.Cancelled, fakeAction2.Token.State);
            Assert.AreEqual(ActionStates.Cancelled, fakeAction3.Token.State);
            // Only send operations left in running actions.
            Assert.AreEqual(2, _sessionClient.RunningActions.Count);
        }

        [Test]
        public void TokenExpired_NoNextFrames_TokenIsExpired_ActionRemovedFromRunning_AddToCallbackBufferBlock()
        {
            // Arrange.
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            _sessionClient.TimeoutManager = new TimeoutManager();
            _sessionClient.TimeoutManager.Start(_sessionClient);
            _sessionClient.SendFramesCallback =
                ahResult =>
                {
                    ahResult.NextFramesCompletedCallback(true);
                    return true;
                };

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            Thread.Sleep(800);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Expired, fakeAction.Token.State);
            // Action removed from running actions.
            Assert.AreEqual(0, _sessionClient.RunningActions.Count);
            // Add action to CallbackBufferBlock.
            _sessionClient.CallbackBufferBlock.Received().Add(fakeAction);
            // Check action token state.
            Assert.IsTrue(fakeAction.Token.WaitCompletedSignal());
        }

        [Test]
        public void TokenExpired_WithParentAction_ParentActionsTokenIsExpired_ChildActionsTokenIsCancelled()
        {
            // Arrange.
            _sessionClient.TimeoutManager = new TimeoutManager();
            _sessionClient.TimeoutManager.Start(_sessionClient);
            _sessionClient.SendFramesCallback = ahRes =>
            {
                ahRes.NextFramesCompletedCallback(true);
                return true;
            };
            var fakeAction = new FakeAction();
            var fakeParentAction = new FakeAction(true, null, 300, fakeAction);

            // Act.
            _sessionClient.ExecuteAsync(fakeParentAction);
            _sessionClient.ExecuteAsync(fakeAction);
            Assert.AreEqual(2, _sessionClient.RunningActions.Count);
            Thread.Sleep(600);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Cancelled, fakeAction.Token.State);
            // Parent token state is cancelled.
            Assert.AreEqual(ActionStates.Expired, fakeParentAction.Token.State);
            // Action removed from running actions.
            Assert.AreEqual(0, _sessionClient.RunningActions.Count);
        }

        [Test]
        public void TokenExpired_WithNextFrames_SendFramesCallbackCalled_TokenIsExpired()
        {
            // Arrange.
            _sessionClient.TimeoutManager = new TimeoutManager();
            _sessionClient.TimeoutManager.Start(_sessionClient);
            var fakeAction = new FakeAction(true, null, 500, new CommandMessage() { Data = new byte[2] });

            var sendFramesCallbackCalled = false;
            _sessionClient.SendFramesCallback =
                ahResult =>
                {
                    sendFramesCallbackCalled = true;
                    ahResult.NextFramesCompletedCallback(true);
                    return true;
                };

            // Act.
            _sessionClient.ExecuteAsync(fakeAction);
            Thread.Sleep(800);

            // Assert.
            // Token state is cancelled.
            Assert.AreEqual(ActionStates.Expired, fakeAction.Token.State);
            // SendFramesCallback called.
            Assert.IsTrue(sendFramesCallbackCalled);
        }

        [Test]
        public void RunComponents_ComponentsIsReady_AllComponentsStarted()
        {
            // Arrange.

            // Act.
            _sessionClient.RunComponents();

            // Assert.
            _sessionClient.TimeoutManager.Received(1).Start(_sessionClient);
            _sessionClient.CallbackBufferBlock.Received(1).Start("CallbackBufferBlock", Arg.Any<Action<IActionItem>>());
            _sessionClient.ActionCaseConsumer.Received(1).Start("DataFramesConsumer", Arg.Any<Action<IActionCase>>());
        }

        private void ActionChangeCallback(ActionToken actionToken)
        {
        }
    }
}
