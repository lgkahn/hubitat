﻿using NUnit.Framework;
using NSubstitute;
using ZWave;
using ZWave.Layers;
using System.Threading;

namespace ZWaveTests
{
    [TestFixture]
    public class TimeoutManagerTests
    {
        private ITimeoutManager _timeoutManager;

        [SetUp]
        public void SetUp()
        {
            _timeoutManager = new TimeoutManager();
        }

        [TearDown]
        public void TearDown()
        {
            _timeoutManager.Dispose();
        }

        //[Test]
        public void AddTimer_ActionTokenBecomesExpired_CallsSessionClientHandleTimeElapsed()
        {
            // Arrange.
            var sessionClientMock = Substitute.For<ISessionClient>();
            var actionToken = new ActionToken(typeof(object), 0, 200, new ActionResult());

            // Act.
            _timeoutManager.Start(sessionClientMock);
            _timeoutManager.AddTimer(actionToken);
            Thread.Sleep(400);

            // Assert.
            sessionClientMock.Received(1).TokenExpired(Arg.Is<ActionToken>(actionToken));
        }

        [Test]
        public void AddTimer_TimeIntervalBecomesExpired_CallsSessionClientHandleTimeElapsed()
        {
            // Arrange.
            var sessionClientMock = Substitute.For<ISessionClient>();
            var timeIntarval = new TimeInterval(1, 200);

            // Act.
            _timeoutManager.Start(sessionClientMock);
            _timeoutManager.AddTimer(timeIntarval);
            Thread.Sleep(300);

            // Assert.
            sessionClientMock.Received(1).HandleActionCase(Arg.Is(timeIntarval));
        }
    }
}
