﻿using NUnit.Framework;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using Utils;
using ZWave;
using ZWave.Layers.Frame;

namespace ZWaveTests
{
    [TestFixture]
    public class FrameBufferBlockTests
    {
        private List<byte> _writtenData;
        private FrameBufferBlock _frameBufferBlock;

        [SetUp]
        public void SetUp()
        {
            _writtenData = new List<byte>();
            _frameBufferBlock = new FrameBufferBlock(WriteData, CreateFrameBuffer);
        }

        [Test]
        public void AddFrames_WithACK_CorrectlyWriteAllData()
        {
            // Arrange.
            var rawData = new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5 };
            var command = new CommandMessage { IsNoAck = false };
            command.AddData(rawData);
            var transmitSucceeded = false;
            var frame = new ActionHandlerResult(new FakeAction());
            frame.NextFramesCompletedCallback =
                succeeded =>
                {
                    transmitSucceeded = succeeded;
                };
            frame.NextActions.AddRange(new CommandMessage[] { command, command, command });

            // Act.
            _frameBufferBlock.Start();
            _frameBufferBlock.Add(frame);

            for (int i = 0; i < frame.NextActions.Count; i++)
            {
                Thread.Sleep(800);
                _frameBufferBlock.Acknowledge(true);
            }

            // Assert.
            Thread.Sleep(500);
            Assert.IsTrue(_writtenData.ToArray().SequenceEqual(new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x0, 0x1, 0x2, 0x3, 0x4, 0x5 }));
            Assert.IsTrue(transmitSucceeded);
            _frameBufferBlock.Stop();
        }

        [Test]
        public void AddFrames_NoACK_MakesThreeAttemptsToWriteData()
        {
            // Arrange.
            var rawData = new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5 };
            var command = new CommandMessage { IsNoAck = false };
            command.AddData(rawData);
            var transmitSucceeded = true;
            var frame = new ActionHandlerResult(new FakeAction());
            frame.NextFramesCompletedCallback =
                succeeded =>
                {
                    transmitSucceeded = succeeded;
                };
            frame.NextActions.AddRange(new CommandMessage[] { command });

            // Act.
            _frameBufferBlock.Start();
            _frameBufferBlock.Add(frame);
            Thread.Sleep(5000);

            // Assert.
            Assert.IsTrue(_writtenData.SequenceEqual(new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x0, 0x1, 0x2, 0x3, 0x4, 0x5 }));
            Assert.IsFalse(transmitSucceeded);
            _frameBufferBlock.Stop();
        }

        [Test]
        public void AddFrames_WithCAN_MakesElevenAttemptsToWriteData()
        {
            // Arrange.
            var rawData = new byte[] { 0x2, 0x3 };
            var command = new CommandMessage { IsNoAck = false };
            command.AddData(rawData);
            var transmitSucceeded = true;
            var frame = new ActionHandlerResult(new FakeAction());
            frame.NextFramesCompletedCallback =
                succeeded =>
                {
                    transmitSucceeded = succeeded;
                };
            frame.NextActions.AddRange(new CommandMessage[] { command });

            // Act.
            _frameBufferBlock.Start();
            _frameBufferBlock.Add(frame);

            const int countCAN = 11;
            for (int i = 0; i < countCAN; i++)
            {
                Thread.Sleep(i * 200 + 100);
                _frameBufferBlock.Acknowledge(false);
            }

            // Assert.
            Assert.IsTrue(_writtenData.SequenceEqual(new byte[] { 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3 }));
            Assert.IsFalse(transmitSucceeded);
            _frameBufferBlock.Stop();
        }

        private int WriteData(byte[] data)
        {
            _writtenData.AddRange(data);
            return data.Length;
        }

        private byte[] CreateFrameBuffer(CommandMessage message)
        {
            return message.Data;
        }
    }
}
