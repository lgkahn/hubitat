﻿using System.Linq;
using NUnit.Framework;
using ZWave.BasicApplication;
using ZWave.BasicApplication.Devices;
using ZWave.BasicApplication.Operations;
using ZWave.CommandClasses;
using ZWave.Enums;
using ZWave;
using System.Collections.Generic;
using Utils;
using ZWave.BasicApplication.Security;
using ZWave.BasicApplication.Tasks;
using ZWave.BasicApplication.Enums;
using System.Threading;
using ZWave.Security.S2;

namespace BasicApplicationTests.RequestNodeInfo
{
    public class NodeInfoTests : TestBase
    {
        public int SUPPORTED_TIMEOUT;

        private byte[] NETWORK_KEY_S2_C0 = new byte[] { 0xc0, 0x07, 0x66, 0xd0, 0xa1, 0x66, 0x65, 0x1f, 0x64, 0x67, 0xe2, 0x01, 0xce, 0xa8, 0x07, 0x5b };
        private byte[] NETWORK_KEY_S2_C1 = new byte[] { 0xc1, 0x62, 0xad, 0xfa, 0xe0, 0x62, 0xea, 0xf8, 0x40, 0x8c, 0x31, 0x97, 0x66, 0x7e, 0xda, 0x0e };
        private byte[] NETWORK_KEY_S2_C2 = new byte[] { 0xc2, 0xfb, 0xdc, 0x1f, 0x16, 0x54, 0x5c, 0x09, 0xf2, 0x26, 0xa6, 0xa0, 0xa1, 0x9a, 0x28, 0x4d };
        private byte[] NETWORK_KEY_S0 = new byte[] { 0x00, 0xb0, 0xe5, 0xd2, 0xe9, 0xd9, 0xea, 0xbc, 0xb4, 0x0c, 0x0d, 0x1b, 0xbe, 0x83, 0xa8, 0xba };

        public byte[] cmdS2SupportedGet = new COMMAND_CLASS_SECURITY_2.SECURITY_2_COMMANDS_SUPPORTED_GET();
        public byte[] cmdS2SupportedReport = new COMMAND_CLASS_SECURITY_2.SECURITY_2_COMMANDS_SUPPORTED_REPORT();
        public byte[] cmdS0SupportedGet = new COMMAND_CLASS_SECURITY.SECURITY_COMMANDS_SUPPORTED_GET();
        public byte[] cmdS0SupportedReport = new COMMAND_CLASS_SECURITY.SECURITY_COMMANDS_SUPPORTED_REPORT();

        private SecurityManagerInfo _smiFirst;
        private SecurityManagerInfo _smiSecond;

        [SetUp]
        public void SetUp()
        {
            SUPPORTED_TIMEOUT = 8 * RequestNodeInfoSecureTask.CMD_SUPPORTED;

            _ctrlFirst.SerialApiGetCapabilities();
            _ctrlSecond.SerialApiGetCapabilities();

            _ctrlFirst.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_SECURITY_2.ID, COMMAND_CLASS_BASIC.ID });
            _ctrlSecond.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_SECURITY_2.ID, COMMAND_CLASS_BASIC.ID });

            _ctrlFirst.SessionClient.AddSubstituteManager(new SupervisionManager(x => true));
            _ctrlSecond.SessionClient.AddSubstituteManager(new SupervisionManager(x => true));

            SetUpSecurity(_ctrlFirst, NETWORK_KEY_S2_C0, NETWORK_KEY_S2_C1, NETWORK_KEY_S2_C2, NETWORK_KEY_S0);
            SetUpSecurity(_ctrlSecond, null, null, null, null);

            _ctrlFirst.Network.IsEnabledS0 = true;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS0 = true;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = true;

            _smiFirst = ((SecurityManager)_ctrlFirst.SessionClient.GetSubstituteManager(typeof(SecurityManager))).SecurityManagerInfo;
            _smiSecond = ((SecurityManager)_ctrlSecond.SessionClient.GetSubstituteManager(typeof(SecurityManager))).SecurityManagerInfo;
        }

        protected void IncludeSecondary()
        {
            var actionTokenAdd = _ctrlFirst.IncludeNode(Modes.NodeAny, INCLUSION_TIMEOUT, null);
            _ctrlFirst.WaitNodeStatusSignal(NodeStatuses.LearnReady, EXPECT_TIMEOUT);
            var actionTokenLearn = _ctrlSecond.SetLearnMode(LearnModes.LearnModeClassic, INCLUSION_TIMEOUT, null);

            var includeRes = actionTokenAdd.WaitCompletedSignal() as InclusionResult;
            var learnRes = actionTokenLearn.WaitCompletedSignal() as SetLearnModeResult;

            Assert.IsTrue(includeRes);
            Assert.IsTrue(learnRes);
            Assert.AreEqual(SubstituteStatuses.Done, includeRes.AddRemoveNode.SubstituteStatus);
            Assert.AreEqual(SubstituteStatuses.Done, learnRes.SubstituteStatus);

            _ctrlFirst.MemoryGetId();
            _ctrlSecond.MemoryGetId();
        }

        [Test]
        public void ReProbingEachKey_InCorrectOrder()
        {
            //Arrange
            IncludeSecondary();
            ListenDataCollector Collector = ListenDataCollector.Create(_ctrlFirst, _ctrlSecond); ;

            //Action
            Collector.Start(true);
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();
            Thread.Sleep(500);
            var logs = Collector.Stop();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);

            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);

            Assert.AreEqual(SecuritySchemeSet.ALL.Length * 2, logs.Count);
            int i = 0;
            foreach (var item in SecuritySchemeSet.ALL)
            {
                Assert.AreEqual(logs[i].First, item);
                Assert.AreEqual(logs[++i].First, item);
                i++;
            }



            //From second
            Collector.Start(true);
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();
            logs = Collector.Stop();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);

            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);

            Assert.AreEqual(SecuritySchemeSet.ALL.Length * 2, logs.Count);
            i = 0;
            foreach (var item in SecuritySchemeSet.ALL)
            {
                Assert.AreEqual(logs[i].First, item);
                Assert.AreEqual(logs[++i].First, item);
                i++;
            }
        }

        [Test]
        public void DisableHighestAfterInclusion_OnSecondary_RequestFromMain_UsesHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme, "Probes Highest");
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme, "but reports on next high available");


            //2.Enable Key Again
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;

            //Act.
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
        }

        [Test]
        public void DisableHighestAfterInclusion_OnSecondary_RequestFromSecondary_UsesHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme, "Probes Highest");
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2.Enable Key Again
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;

            //Act.
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
        }

        [Ignore("")]
        [Test]
        public void DisableHighestAfterInclusion_OnSecondary_RequestFromBoth_UsesHighestAvailable()
        {
            //TODO:
        }

        [Test]
        public void DisableHighestAfterInclusion_OnPrimary_RequestFromMain_UsesHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;

            //Action
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
        }

        [Test]
        public void DisableHighestAfterInclusion_OnPrimary_RequestFromSecondary_UsesHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;

            //Action
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
        }

        [Ignore("")]
        [Test]
        public void DisableHighestAfterInclusion_OnPrimary_RequestFromBoth_UsesHighestAvailable()
        {
            //TODO:
        }

        [Test]
        public void DisableAllS2AfterInclusion_OnPrimary_RequestFromMain_RestoresHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_UNAUTHENTICATED));

            //2. Restore Key

            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_ACCESS));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Test]
        public void DisableAllS2AfterInclusion_OnPrimary_RequestFromSecondary_RestoresHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            //check nonce get? 
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_UNAUTHENTICATED));

            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_ACCESS));
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Ignore("")]
        [Test]
        public void DisableAllS2AfterInclusion_OnPrimary_RequestFromBoth_RestoresHighestAvailable()
        {
            //TODO:
        }

        [Test]
        public void DisableAllS2AfterInclusion_OnSecondary_RequestFromMain_RestoresHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            _ctrlSecond.Network.IsEnabledS0 = true;
            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command, "Tries get with highest");
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));


            //2. Restore Key
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;
            _ctrlSecond.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_ACCESS));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Test]
        public void DisableAllS2AfterInclusion_OnSecondary_RequestFromSecondary_RestoresHighestAvailable()
        {
            //Arrange
            IncludeSecondary();
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            _ctrlSecond.Network.IsEnabledS0 = true;
            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemeSet.ALLS2));


            //2. Restore Key
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;
            _ctrlSecond.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_ACCESS));
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsTrue(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Ignore("")]
        [Test]
        public void DisableAllS2AfterInclusion_OnSecondary_RequestFromBoth_RestoresHighestAvailable()
        {
            //TODO:
        }

        [TestCase(SecuritySchemes.S2_ACCESS)]
        [TestCase(SecuritySchemes.S2_AUTHENTICATED)]
        [TestCase(SecuritySchemes.S2_UNAUTHENTICATED)]
        [TestCase(SecuritySchemes.S2_TEMP)]
        [TestCase(SecuritySchemes.S0)]
        [TestCase(SecuritySchemes.NONE)]
        public void SetActiveScheme_Restores_HighestAvailable(SecuritySchemes testScheme)
        {
            //Arrange
            IncludeSecondary();
            _ctrlFirst.Network.SetCurrentSecurityScheme(NODE_ID_2, testScheme);

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);
        }

        [Test]
        public void KEXConfirm_GrantOnlyS0_AffterIncluion_UseOnlyS0()
        {
            // Arrange
            var sm = (SecurityManager)_ctrlFirst.SessionClient.GetSubstituteManager(typeof(SecurityManager));
            sm.SecurityManagerInfo.KEXSetConfirmCallback = ((requestedSchemes, isClientSideAuthRequested) =>
                {
                    var ret = new KEXSetConfirmResult();
                    ret.GrantedSchemes = new System.Collections.Generic.List<SecuritySchemes>();
                    ret.GrantedSchemes.Add(SecuritySchemes.S0);
                    ret.IsConfirmed = true;
                    return ret;
                });
            IncludeSecondary();

            // Action1
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);
            _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            // Assert
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S0));

            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);

            var expectToken = _ctrlSecond.ExpectData(new COMMAND_CLASS_BASIC.BASIC_SET(), EXPECT_TIMEOUT, null);
            var sendRes = _ctrlFirst.SendData(_ctrlSecond.Id, new COMMAND_CLASS_BASIC.BASIC_SET(), TXO);
            var expectRes = (ExpectDataResult)expectToken.WaitCompletedSignal();

            Assert.AreEqual(SecuritySchemes.S0, (SecuritySchemes)expectRes.SecurityScheme);
        }

        [Test]
        public void KEXConfirm_GrantOnlyS2All_AffterIncluion_UseS2Access()
        {
            // Arrange
            var sm = (SecurityManager)_ctrlFirst.SessionClient.GetSubstituteManager(typeof(SecurityManager));
            sm.SecurityManagerInfo.KEXSetConfirmCallback = ((requestedSchemes, isClientSideAuthRequested) =>
            {
                var ret = new KEXSetConfirmResult();
                ret.GrantedSchemes = new System.Collections.Generic.List<SecuritySchemes>();
                ret.GrantedSchemes.AddRange(SecuritySchemeSet.ALLS2);
                ret.IsConfirmed = true;
                return ret;
            });
            IncludeSecondary();
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S0));

            // Action1
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);
            _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            // Assert
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S0));

            Assert.Null(actualGetS0Res.Command);
            Assert.Null(actualReportS0Res.Command);
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_ACCESS, actualReportS2Res.SecurityScheme);

            var expectToken = _ctrlSecond.ExpectData(new COMMAND_CLASS_BASIC.BASIC_SET(), SUPPORTED_TIMEOUT, null);
            var sendRes = _ctrlFirst.SendData(_ctrlSecond.Id, new COMMAND_CLASS_BASIC.BASIC_SET(), TXO);
            var expectRes = (ExpectDataResult)expectToken.WaitCompletedSignal();

            Assert.AreEqual(SecuritySchemes.S2_ACCESS, (SecuritySchemes)expectRes.SecurityScheme);
        }

        [TestCase(SecuritySchemes.S2_ACCESS)]
        [TestCase(SecuritySchemes.S2_AUTHENTICATED)]
        [TestCase(SecuritySchemes.S2_UNAUTHENTICATED)]
        public void KEXConfirm_GrantOnlyOneS2_AffterIncluion_UseOnlyTestScheme(SecuritySchemes testScheme)
        {
            // Arrange
            var sm = (SecurityManager)_ctrlFirst.SessionClient.GetSubstituteManager(typeof(SecurityManager));
            sm.SecurityManagerInfo.KEXSetConfirmCallback = ((requestedSchemes, isClientSideAuthRequested) =>
            {
                var ret = new KEXSetConfirmResult();
                ret.GrantedSchemes = new System.Collections.Generic.List<SecuritySchemes>();
                ret.GrantedSchemes.Add(testScheme);
                ret.IsConfirmed = true;
                return ret;
            });
            IncludeSecondary();

            // Action1
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);
            _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            // Assert
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));
            Assert.IsTrue(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, testScheme));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S0));

            Assert.Null(actualGetS0Res.Command);
            Assert.Null(actualReportS0Res.Command);
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(testScheme, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(testScheme, actualReportS2Res.SecurityScheme);

            _ctrlSecond.RequestNodeInfo(NODE_ID_1);
            var expectToken = _ctrlSecond.ExpectData(new COMMAND_CLASS_BASIC.BASIC_SET(), EXPECT_TIMEOUT, null);
            var sendRes = _ctrlFirst.SendData(_ctrlSecond.Id, new COMMAND_CLASS_BASIC.BASIC_SET(), TXO);
            var expectRes = (ExpectDataResult)expectToken.WaitCompletedSignal();

            Assert.AreEqual(testScheme, (SecuritySchemes)expectRes.SecurityScheme);

            _ctrlFirst.RequestNodeInfo(NODE_ID_2);
            expectToken = _ctrlSecond.ExpectData(new COMMAND_CLASS_BASIC.BASIC_SET(), EXPECT_TIMEOUT, null);
            sendRes = _ctrlFirst.SendData(_ctrlSecond.Id, new COMMAND_CLASS_BASIC.BASIC_SET(), TXO);
            expectRes = (ExpectDataResult)expectToken.WaitCompletedSignal();

            Assert.AreEqual(testScheme, (SecuritySchemes)expectRes.SecurityScheme);
        }

        [Ignore("Supported Command Classes Get/Report by scheme")]
        [Test]
        public void RequestSupportedCommandClassFromSecondary_AllKeys_ReturnsOnlyForHighest()
        {
            //or add this check for needed tests*

            //suported CC's and securely supported CC's
        }

        [Test]
        public void DisableHighest_BeforeInclusion_OnSecondary_RequestFromMain_MainTriesS2_AccessWithoutResponce()
        {
            //Arrange
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            IncludeSecondary();

            //Action
            byte[] s2MEC = new COMMAND_CLASS_SECURITY_2.SECURITY_2_MESSAGE_ENCAPSULATION();
            var s2mecToken = _ctrlSecond.ExpectData(s2MEC, SUPPORTED_TIMEOUT, null);
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualS2mecRes = (ExpectDataResult)s2mecToken.WaitCompletedSignal();
            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualS2mecRes.Command, "not decrypted frame - S2_Access Supported Get");
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2.Enable Key Again
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;

            //Act.
            s2mecToken = _ctrlSecond.ExpectData(new COMMAND_CLASS_SECURITY_2.SECURITY_2_MESSAGE_ENCAPSULATION(), SUPPORTED_TIMEOUT, null);
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualS2mecRes = (ExpectDataResult)s2mecToken.WaitCompletedSignal();
            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualS2mecRes.Command, "not decrypted frame - S2_Access Supported Get");
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);
        }

        [Test]
        public void DisableHighest_BeforeInclusion_OnSecondary_RequestFromSecondary_NotUsesHighestAvailable()
        {
            //Arrange
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            IncludeSecondary();

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2.Enable Key Again
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;

            //Act.
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);
        }

        [Ignore("")]
        [Test]
        public void DisableHighest_BeforeInclusion_OnSecondary_RequestFromBoth_UsesHighestAvailable()
        {
            //TODO:
        }

        [Test]
        public void DisableHighest_BeforeInclusion_OnPrimary_RequestFromMain_NotUsesHighestAvailable()
        {
            //Arrange
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            IncludeSecondary();

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;

            //Action
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);
        }

        [Test]
        public void DisableHighest_BeforeInclusion_OnPrimary_RequestFromSecondary_NotUsesHighestAvailable()
        {
            //Arrange
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            IncludeSecondary();

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);


            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;

            //Action
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.NotNull(actualGetS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualGetS2Res.SecurityScheme);
            Assert.NotNull(actualReportS2Res.Command);
            Assert.AreEqual(SecuritySchemes.S2_AUTHENTICATED, actualReportS2Res.SecurityScheme);
        }

        [Ignore("")]
        [Test]
        public void DisableHighest_BeforeInclusion_OnPrimary_RequestFromBoth_UsesHighestAvailable()
        {
            //TODO:
        }

        [Test]
        public void DisableAllS2_BeforeInclusion_OnPrimary_RequestFromMain_UseOnlyS0()
        {
            //Arrange
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            _ctrlFirst.Network.IsEnabledS0 = true;
            _ctrlFirst.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_BASIC.ID });

            IncludeSecondary();

            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_UNAUTHENTICATED));

            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            _smiFirst.CheckIfSupportSecurityCC = false;
            _smiSecond.CheckIfSupportSecurityCC = false;

            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Test]
        public void DisableAllS2_BeforeInclusion_OnPrimary_RequestFromSecondary_UseOnlyS0()
        {
            //Arrange
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = false;
            _ctrlFirst.Network.IsEnabledS0 = true;
            _ctrlFirst.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_BASIC.ID });

            IncludeSecondary();

            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_UNAUTHENTICATED));

            //2. Restore Key
            _ctrlFirst.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlFirst.Network.IsEnabledS2_ACCESS = true;
            _ctrlFirst.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_ACCESS));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_AUTHENTICATED));
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S2_UNAUTHENTICATED));
        }

        [Ignore("")]
        [Test]
        public void DisableAllS2_BeforeInclusion_OnPrimary_RequestFromBoth_UseOnlyS0()
        {
            //TODO:
        }

        [Test]
        public void DisableAllS2_BeforeInclusion_OnSecondary_RequestFromMain_UseOnlyS0()
        {
            //Arrange
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            _ctrlSecond.Network.IsEnabledS0 = true;
            _ctrlSecond.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_BASIC.ID });

            IncludeSecondary();
            //Action
            var getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlSecond.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlFirst.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));


            //2. Restore Key
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;
            _ctrlSecond.Network.IsEnabledS0 = true;

            //Action
            getS2Token = _ctrlSecond.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlFirst.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlFirst.RequestNodeInfo(NODE_ID_2);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlFirst.Network.HasSecurityScheme(NODE_ID_2, SecuritySchemeSet.ALLS2));
        }

        [Test]
        public void DisableAllS2_BeforeInclusion_OnSecondary_RequestFromSecondary_UseOnlyS0()
        {
            //Arrange
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = false;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = false;
            _ctrlSecond.Network.IsEnabledS0 = true;
            _ctrlSecond.ApplicationNodeInformation(true, 1, 1, new byte[] { COMMAND_CLASS_SECURITY.ID, COMMAND_CLASS_BASIC.ID });

            IncludeSecondary();
            //Action
            var getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            var getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            var reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            var r1 = _ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S0);
            var res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);
            var r2 = _ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemes.S0);

            var actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            var actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            var actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            var actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemeSet.ALLS2));


            //2. Restore Key
            _ctrlSecond.Network.IsEnabledS2_UNAUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_AUTHENTICATED = true;
            _ctrlSecond.Network.IsEnabledS2_ACCESS = true;
            _ctrlSecond.Network.IsEnabledS0 = true;

            //Action
            _smiFirst.CheckIfSupportSecurityCC = false;
            _smiSecond.CheckIfSupportSecurityCC = false;

            getS2Token = _ctrlFirst.ExpectData(cmdS2SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS2Token = _ctrlSecond.ExpectData(cmdS2SupportedReport, SUPPORTED_TIMEOUT, null);
            getS0Token = _ctrlFirst.ExpectData(cmdS0SupportedGet, SUPPORTED_TIMEOUT, null);
            reportS0Token = _ctrlSecond.ExpectData(cmdS0SupportedReport, SUPPORTED_TIMEOUT, null);

            res = _ctrlSecond.RequestNodeInfo(NODE_ID_1);

            actualGetS2Res = (ExpectDataResult)getS2Token.WaitCompletedSignal();
            actualReportS2Res = (ExpectDataResult)reportS2Token.WaitCompletedSignal();
            actualGetS0Res = (ExpectDataResult)getS0Token.WaitCompletedSignal();
            actualReportS0Res = (ExpectDataResult)reportS0Token.WaitCompletedSignal();

            //Assert
            Assert.Null(actualGetS2Res.Command);
            Assert.Null(actualReportS2Res.Command);
            Assert.NotNull(actualGetS0Res.Command);
            Assert.NotNull(actualReportS0Res.Command);
            Assert.AreEqual(SecuritySchemes.S0, actualGetS0Res.SecurityScheme);
            Assert.AreEqual(SecuritySchemes.S0, actualReportS0Res.SecurityScheme);
            Assert.IsFalse(_ctrlSecond.Network.HasSecurityScheme(NODE_ID_1, SecuritySchemeSet.ALLS2));
        }

        [Ignore("")]
        [Test]
        public void DisableAllS2_BeforeInclusion_OnSecondary_RequestFromBoth_UseOnlyS0()
        {
            //TODO:
        }

    }

    public class ListenDataCollector
    {
        private static ListenDataCollector _instance;
        private List<Pair<SecuritySchemes, byte[]>> _collectedItems;
        private Controller _primary;
        private Controller _secondary;
        private ActionToken _primaryCollectToken = null;
        private ActionToken _secondaryCollectToken = null;

        private ListenDataCollector() { }

        public byte[] filterOnSecondary1;
        public byte[] filterOnPrimary1;
        public byte[] filterOnSecondary2;
        public byte[] filterOnPrimary2;

        public static ListenDataCollector Create(Controller primary, Controller secondary)
        {
            if (_instance == null)
            {
                _instance = new ListenDataCollector();
            }
            _instance._collectedItems = new List<Pair<SecuritySchemes, byte[]>>();
            _instance._primary = primary;
            _instance._secondary = secondary;
            _instance.filterOnPrimary1 = new COMMAND_CLASS_SECURITY_2.SECURITY_2_COMMANDS_SUPPORTED_REPORT();
            _instance.filterOnPrimary2 = new COMMAND_CLASS_SECURITY.SECURITY_COMMANDS_SUPPORTED_REPORT();
            _instance.filterOnSecondary1 = new COMMAND_CLASS_SECURITY_2.SECURITY_2_COMMANDS_SUPPORTED_GET();
            _instance.filterOnSecondary2 = new COMMAND_CLASS_SECURITY.SECURITY_COMMANDS_SUPPORTED_GET();
            return _instance;
        }

        public void Start(bool isEnabledFilter)
        {
            _instance._primaryCollectToken = _primary.ListenData((x) =>
            {
                if (x.Command != null && x.Command.Length > 1)
                {
                    if (isEnabledFilter)
                    {
                        if (x.Command.Take(2).ToArray().SequenceEqual(filterOnPrimary1.Take(2).ToArray()) ||
                            x.Command.Take(2).ToArray().SequenceEqual(filterOnPrimary2.Take(2).ToArray()))
                        {

                            _instance._collectedItems.Add(new Pair<SecuritySchemes, byte[]>((SecuritySchemes)x.SecurityScheme, x.Command));
                        }
                    }
                    else
                    {
                        _instance._collectedItems.Add(new Pair<SecuritySchemes, byte[]>((SecuritySchemes)x.SecurityScheme, x.Command));
                    }
                }
            });
            _instance._secondaryCollectToken = _secondary.ListenData((x) =>
            {
                if (x.Command != null && x.Command.Length > 1)
                {
                    if (isEnabledFilter)
                    {
                        if (x.Command.Take(2).ToArray().SequenceEqual(filterOnSecondary1.Take(2).ToArray()) ||
                            x.Command.Take(2).ToArray().SequenceEqual(filterOnSecondary2.Take(2).ToArray()))
                        {
                            _instance._collectedItems.Add(new Pair<SecuritySchemes, byte[]>((SecuritySchemes)x.SecurityScheme, x.Command));
                        }
                    }
                    else
                    {
                        _instance._collectedItems.Add(new Pair<SecuritySchemes, byte[]>((SecuritySchemes)x.SecurityScheme, x.Command));
                    }
                }
            });
        }

        public List<Pair<SecuritySchemes, byte[]>> Stop()
        {
            _instance._primary.Cancel(_instance._primaryCollectToken);
            _instance._primaryCollectToken.WaitCompletedSignal();
            _instance._secondary.Cancel(_instance._secondaryCollectToken);
            _instance._secondaryCollectToken.WaitCompletedSignal();
            return new List<Pair<SecuritySchemes, byte[]>>(_instance._collectedItems);
        }
    }
}