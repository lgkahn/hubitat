﻿using NUnit.Framework;
using Utils;
using ZWave.BasicApplication.Operations;
using ZWave.BasicApplication;
using ZWave.BasicApplication.TransportService.Operations;
using ZWave;
using ZWave.Security;

namespace BasicApplicationTests
{
    [SetUpFixture]
    public class SetupFixture
    {
        [OneTimeSetUp]
        public void RunBeforeAnyTests()
        {
            TimeoutManager.TICK = 55;
            SecurityManager.SC_FOLLOWUP_TIMEOUT = 33;
            int TIMEOUT = 111;

            SetLearnModeS0Operation.CMD_TIMEOUT = TIMEOUT;

            InclusionS2TimeoutConstants.Joining.SetTestTimeouts(TIMEOUT);

            InclusionS2TimeoutConstants.Including.SetTestTimeouts(TIMEOUT);

            SendDataSecureTask.NONCE_REQUEST_TIMER = TIMEOUT;
            SendDataSecureTask.NONCE_REQUEST_INCLUSION_TIMER = TIMEOUT;

            SendDataSecureS2Task.NONCE_REQUEST_TIMER = TIMEOUT;
            SendDataSecureS2Task.NONCE_REQUEST_INCLUSION_TIMER = TIMEOUT;

            RequestNodeInfoSecureTask.CMD_SUPPORTED = TIMEOUT;
            RequestNodeInfoSecureTask.START_DELAY = 1;

            CallbackApiOperation.RET_TIMEOUT = TIMEOUT;
            CallbackApiOperation.CALLBACK_TIMEOUT = TIMEOUT;

            RequestApiOperation.RET_TIMEOUT = TIMEOUT;

            SendDataTransportTask.SEGMENT_COMPLETE_TIMEOUT = TIMEOUT;


            ActionToken.DefaultTimeout = 7777;
            ActionToken.ThrowExceptionOnDefaultTimeoutExpired = true;

            Tools.IsOutputToConsole = true;
        }

        [OneTimeTearDown]
        public void RunAfterAnyTests()
        {
        }
    }
}
