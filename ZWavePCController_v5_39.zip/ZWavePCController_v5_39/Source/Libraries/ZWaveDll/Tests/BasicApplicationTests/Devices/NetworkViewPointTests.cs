﻿using NUnit.Framework;
using ZWave.Enums;
using ZWave.Devices;

namespace BasicApplicationTests.Devices
{
    [TestFixture]
    public class NetworkViewPointTests
    {
        [Test]
        public void NetworkSetNodeIncluded_IsNodeIncluded()
        {
            //Arrange
            var network = new NetworkViewPoint(null);
            const byte NODE_ID = 33;

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllIncluded_IsAllIncluded()
        {
            //Arrange
            var network = new NetworkViewPoint(null);

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
            }

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllIncludedAndClear_IsAllNotIncluded()
        {
            //Arrange
            var network = new NetworkViewPoint(null);

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
            }
            network.ResetAndEnableAndSelfRestore();

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllSecureS0_IsAllSecureS0()
        {
            //Arrange
            var network = new NetworkViewPoint(null);
            network.IsEnabledS0 = true;

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemes(nodeId, SecuritySchemeSet.S0);
            }

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALLS2));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllSecureS0AndClear_IsAllNotSecureS0()
        {
            //Arrange
            var network = new NetworkViewPoint(null);

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemes(nodeId, SecuritySchemeSet.S0);
            }
            network.ResetAndEnableAndSelfRestore();

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALLS2));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllSecureS2_IsAllSecureS2()
        {
            //Arrange
            var network = new NetworkViewPoint(null);
            SecuritySchemes[] schemes = new SecuritySchemes[] { SecuritySchemes.S0, SecuritySchemes.S2_ACCESS };
            network.IsEnabledS2_ACCESS = true;
            network.IsEnabledS0 = true;

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemes(nodeId, schemes);
            }

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALLS2));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_UNAUTHENTICATED));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_AUTHENTICATED));
                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_ACCESS));



                Assert.IsTrue(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }


        [Test]
        public void NetworkSetAllSecureS2AndClear_IsAllNotSecureS2()
        {
            //Arrange
            var network = new NetworkViewPoint(null);
            SecuritySchemes[] schemes = new SecuritySchemes[] { SecuritySchemes.S0, SecuritySchemes.S2_ACCESS };

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemes(nodeId, schemes);
            }
            network.ResetAndEnableAndSelfRestore();

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALLS2));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_UNAUTHENTICATED));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_AUTHENTICATED));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S2_ACCESS));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemes.S0));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllSecuritySpecified_IsAllSecuritySpecified()
        {
            //Arrange
            var network = new NetworkViewPoint(null);

            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemesSpecified(nodeId);
            }

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                Assert.IsTrue(network.IsSecuritySchemesSpecified(nodeId));
                Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
            }
        }

        [Test]
        public void NetworkSetAllSecuritySpecifiedAndClear_IsAllNotSecuritySpecified()
        {
            //Arrange
            var network = new NetworkViewPoint(null);
            network.NodeId = 33;
            //Act
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                network.SetSecuritySchemesSpecified(nodeId);
            }
            network.ResetAndEnableAndSelfRestore();

            //Assert
            for (int i = 0; i < 256; i++)
            {
                byte nodeId = (byte)i;
                if (i != network.NodeId)
                {
                    Assert.IsFalse(network.IsSecuritySchemesSpecified(nodeId));
                    Assert.IsFalse(network.HasSecurityScheme(nodeId, SecuritySchemeSet.ALL));
                }
            }
        }
    }
}
