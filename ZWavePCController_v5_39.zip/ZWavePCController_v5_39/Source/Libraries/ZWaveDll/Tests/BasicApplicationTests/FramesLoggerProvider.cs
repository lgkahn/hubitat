﻿using ZWave.Layers;
using ZWave.BasicApplication.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;

namespace BasicApplicationTests
{
    public static class FramesLoggerProvider
    {
        private static List<FrameLogRecord> _framesLog = new List<FrameLogRecord>();
        public static ReadOnlyCollection<FrameLogRecord> FramesLog { get { return _framesLog.AsReadOnly(); } }

        public static void ClearLog()
        {
            _framesLog.Clear();
        }

        public static void FrameLayer_FrameTransmitted(object sender, Utils.Events.EventArgs<IDataFrame> e)
        {
            //ReportToConsole(e.Value);
            if (e.Value.SessionId == 0)
            {
                if (e.Value.Data.Length < 7)
                    return;

                if (e.Value.Data[1] == (byte)CommandTypes.CmdZWaveSendData)
                {
                    _framesLog.Add(FrameLogRecord.Create(0, e.Value.Data[2], e.Value.Data[5]));
                }
                else if (e.Value.Data[1] == (byte)CommandTypes.CmdApplicationCommandHandler)
                {
                    _framesLog.Add(FrameLogRecord.Create(e.Value.Data[3], 0, e.Value.Data[6]));
                }
            }
        }

        public static void FrameLayer_FrameTransmittedToConsole(object sender, Utils.Events.EventArgs<IDataFrame> e)
        {
            //ReportToConsole(e.Value);
        }

        private static void ReportToConsole(IDataFrame dataFrame)
        {
            Console.Out.WriteLine("{0:HH:mm:ss.fff} {1:000} {2} {3}",
                dataFrame.SystemTimeStamp,
                dataFrame.SessionId,
                dataFrame.IsOutcome ? ">>" : "<<",
                dataFrame);
        }
    }
}
