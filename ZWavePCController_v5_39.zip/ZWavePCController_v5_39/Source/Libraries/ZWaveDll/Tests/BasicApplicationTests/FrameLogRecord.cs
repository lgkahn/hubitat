﻿using ZWave.Enums;

namespace BasicApplicationTests
{
    public class FrameLogRecord
    {
        public byte FromNodeId { get; private set; }
        public byte ToNodeId { get; private set; }
        public byte CmdId { get; private set; }

        public override bool Equals(object obj)
        {
            var frameRecord = obj as FrameLogRecord;
            if (frameRecord == null)
                return false;

            if (this == frameRecord)
                return true;

            return this.CmdId == frameRecord.CmdId &&
                this.FromNodeId == frameRecord.FromNodeId &&
                this.ToNodeId == frameRecord.ToNodeId;
        }

        public override int GetHashCode()
        {
            return FromNodeId ^ ToNodeId ^ CmdId;
        }

        private FrameLogRecord()
        {
        }

        public static FrameLogRecord Create(byte fromNodeId, byte toNodeId, byte cmdId)
        {
            return new FrameLogRecord
            {
                FromNodeId = fromNodeId,
                ToNodeId = toNodeId,
                CmdId = cmdId
            };
        }
    }
}
