﻿using System.Collections.Generic;
using NUnit.Framework;
using ZWave.Enums;
using ZWave.BasicApplication;
using ZWave.BasicApplication.Devices;
using ZWave.CommandClasses;
using ZWave.Security;
using ZWave.Layers;
using ZWave.Layers.Session;
using ZWave.Configuration;
using ZWave.BasicApplication.EmulatedLink;

namespace BasicApplicationTests
{
    public class TestBase
    {
        #region Hardcodes
        protected const int EXPECT_TIMEOUT = 123;
        protected const int INCLUSION_TIMEOUT = 234;

        protected const byte NODE_ID_1 = 0x01;
        protected const byte NODE_ID_2 = 0x02;
        protected const byte NODE_ID_3 = 0x03;
        protected readonly InvariantPeerNodeId PEER_NODE_ID_2 = new InvariantPeerNodeId(NODE_ID_1, NODE_ID_2);
        protected readonly InvariantPeerNodeId PEER_NODE_ID_1 = new InvariantPeerNodeId(NODE_ID_2, NODE_ID_1);
        protected readonly TransmitOptions TXO = TransmitOptions.TransmitOptionAcknowledge |
            TransmitOptions.TransmitOptionAutoRoute |
            TransmitOptions.TransmitOptionExplore;

        #endregion

        protected Controller _ctrlFirst;
        protected Controller _ctrlSecond;
        protected Controller _ctrlThird;
        protected TransmitOptions _txOptions = TransmitOptions.TransmitOptionAcknowledge;
        protected BasicLinkTransportLayer _transport;
        protected BasicApplicationLayer _app;

        [SetUp]
        public void SetUpBase()
        {
            _transport = new BasicLinkTransportLayer();
            _app = new BasicApplicationLayer(new SessionLayer(), new BasicFrameLayer(), _transport);
            _app.FrameLayer.FrameTransmitted += FramesLoggerProvider.FrameLayer_FrameTransmitted;

            FramesLoggerProvider.ClearLog();
            _ctrlFirst = _app.CreateController();
            _ctrlSecond = _app.CreateController();
            _ctrlThird = _app.CreateController();

            _ctrlFirst.Connect(new SerialPortDataSource("COM1"));
            _ctrlSecond.Connect(new SerialPortDataSource("COM2"));
            _ctrlThird.Connect(new SerialPortDataSource("COM3"));

            _ctrlFirst.MemoryGetId();
            _ctrlSecond.MemoryGetId();
            _ctrlThird.MemoryGetId();
        }

        [TearDown]
        public void TearDownBase()
        {
            _ctrlFirst.Dispose();
            _ctrlSecond.Dispose();
            _ctrlThird.Dispose();
        }

        protected void SetUpSecurity(Controller ctrl)
        {
            SetUpSecurity(ctrl, null, null, null, null);
        }

        protected void SetUpSecurity(Controller ctrl, byte[] keyS2C0, byte[] keyS2C1, byte[] keyS2C2, byte[] keyS0)
        {
            NetworkKey[] nkeys = new NetworkKey[8];
            nkeys[0] = new NetworkKey(keyS2C0);
            nkeys[1] = new NetworkKey(keyS2C1);
            nkeys[2] = new NetworkKey(keyS2C2);
            nkeys[7] = new NetworkKey(keyS0);

            var securityManager = new SecurityManager(ctrl.Network,
                nkeys,
                new byte[]
                {
                        0x77, 0x07, 0x6d, 0x0a, 0x73, 0x18, 0xa5, 0x7d, 0x3c, 0x16, 0xc1, 0x72, 0x51, 0xb2, 0x66, 0x45,
                        0xdf, 0x4c, 0x2f, 0x87, 0xeb, 0xc0, 0x99, 0x2a, 0xb1, 0x77, 0xfb, 0xa5, 0x1d, 0xb9, 0x2c, 0x2a
                });

            securityManager.SecurityManagerInfo.CheckIfSupportSecurityCC = true;
            securityManager.SecurityManagerInfo.DSKNeededCallback = (nodeId, DSKFull) =>
            {
                return new byte[] { 0x85, 0x20 };
            };
            securityManager.SecurityManagerInfo.DSKVerificationOnReceiverCallback = () =>
            {
                return new byte[] { 0x85, 0x20, 0xF0, 0x09 };
            };
            securityManager.SecurityManagerInfo.SetTestSecretKeyS2(new byte[]
            {
                0x77, 0x07, 0x6d, 0x0a, 0x73, 0x18, 0xa5, 0x7d, 0x3c, 0x16, 0xc1, 0x72, 0x51, 0xb2, 0x66, 0x45,
                0xdf, 0x4c, 0x2f, 0x87, 0xeb, 0xc0, 0x99, 0x2a, 0xb1, 0x77, 0xfb, 0xa5, 0x1d, 0xb9, 0x2c, 0x2a
            });

            ctrl.SessionClient.AddSubstituteManager(securityManager);
            ctrl.SessionClient.ExecuteAsync(securityManager.CreateSecurityReportTask());
            ctrl.SessionClient.ExecuteAsync(securityManager.CreateSecurityS2ReportTask());
        }

        protected void AssertCmdSequence(FrameLogRecord[] expectedCmds)
        {
            Assert.AreEqual(expectedCmds.Length, FramesLoggerProvider.FramesLog.Count);
            for (int i = 0; i < expectedCmds.Length; i++)
            {
                Assert.IsTrue(expectedCmds[i].Equals(FramesLoggerProvider.FramesLog[i]));
            }
        }

        protected byte[] CreateDataAsDoorLookConfigurationGet()
        {
            return new COMMAND_CLASS_DOOR_LOCK.DOOR_LOCK_CONFIGURATION_GET();
        }

        protected byte[] CreateDataAsVeryLongBasicGet(int numOfAdditionalBytes)
        {
            List<byte> tmpData = new List<byte>();
            byte[] cmd = new COMMAND_CLASS_BASIC.BASIC_GET();
            tmpData.AddRange(cmd);
            for (int i = 0; i < numOfAdditionalBytes; i++)
            {
                tmpData.Add((byte)i);
            }
            return tmpData.ToArray();
        }
    }
}
