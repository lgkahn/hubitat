﻿using System.Linq;
using System.Collections.Generic;
using NUnit.Framework;
using ZWave.CommandClasses;
using ZWave.BasicApplication.Operations;
using ZWave;
using ZWave.BasicApplication;

namespace BasicApplicationTests.Supervision
{
    [TestFixture]
    public class SendDataSupervisionTests : TestBase
    {
        #region Hardcodes

        private const int SUPERVISION_REPORT_TIMEOUT = 222;

        #endregion

        [SetUp]
        public void SetUp()
        {
            _transport.SetUpModulesNetwork(_ctrlFirst.SessionId, _ctrlSecond.SessionId);
            _ctrlFirst.SessionClient.AddSubstituteManager(new SupervisionManager(x => true));
            _ctrlSecond.SessionClient.AddSubstituteManager(new SupervisionManager(x => true));
        }

        [Test]
        public void A_SendData_WrappedWithSupervisionGetCommand_SupervisionReportIsReceived()
        {
            // Arange.
            byte[] primaryCmd = CreateDataAsDoorLookConfigurationGet();
            byte[] supervisionWrappedCmd = CreateSupervisionCmd(primaryCmd);

            // Act.
            var expectSupervisionReportToken = _ctrlFirst.ExpectData(new COMMAND_CLASS_SUPERVISION.SUPERVISION_REPORT(), SUPERVISION_REPORT_TIMEOUT, null);
            var expectPrimaryCmdToken = _ctrlSecond.ExpectData(primaryCmd, SUPERVISION_REPORT_TIMEOUT, null);
            _ctrlFirst.SendData(NODE_ID_2, supervisionWrappedCmd, TXO);
            var expectPrimaryCmdRes = (ExpectDataResult)expectPrimaryCmdToken.WaitCompletedSignal();
            var expectSupervisionReportCmdRes = (ExpectDataResult)expectSupervisionReportToken.WaitCompletedSignal();

            // Assert.
            Assert.AreEqual(expectPrimaryCmdRes.State, ActionStates.Completed);
            Assert.IsTrue(expectPrimaryCmdRes.Command.SequenceEqual(primaryCmd));
            Assert.AreEqual(expectSupervisionReportCmdRes.State, ActionStates.Completed);
            AssertCmdSequence(new FrameLogRecord[]
            {
                FrameLogRecord.Create(0, NODE_ID_2, COMMAND_CLASS_SUPERVISION.SUPERVISION_GET.ID),
                FrameLogRecord.Create(NODE_ID_2, 0, COMMAND_CLASS_SUPERVISION.SUPERVISION_REPORT.ID)
            });
        }

        [Test]
        public void SendData_FrameIsFollowup_WrappedWithSupervisionGetCommand()
        {
            // Arange.
            byte[] primaryCmd = CreateDataAsDoorLookConfigurationGet();

            // Act.
            var expectSupervisionReportToken = _ctrlFirst.ExpectData(new COMMAND_CLASS_SUPERVISION.SUPERVISION_REPORT(), SUPERVISION_REPORT_TIMEOUT, null);
            var expectPrimaryCmdToken = _ctrlSecond.ExpectData(primaryCmd, SUPERVISION_REPORT_TIMEOUT, null);
            _ctrlFirst.SendData(NODE_ID_2, primaryCmd, TXO, null, true /*Frame is Followup*/);
            var expectPrimaryCmdRes = (ExpectDataResult)expectPrimaryCmdToken.WaitCompletedSignal();
            var expectSupervisionReportCmdRes = (ExpectDataResult)expectSupervisionReportToken.WaitCompletedSignal();

            // Assert.
            Assert.AreEqual(expectPrimaryCmdRes.State, ActionStates.Completed);
            Assert.IsTrue(expectPrimaryCmdRes.Command.SequenceEqual(primaryCmd));
            Assert.AreEqual(expectSupervisionReportCmdRes.State, ActionStates.Completed);
            AssertCmdSequence(new FrameLogRecord[]
            {
                FrameLogRecord.Create(0, NODE_ID_2, COMMAND_CLASS_SUPERVISION.SUPERVISION_GET.ID),
                FrameLogRecord.Create(NODE_ID_2, 0, COMMAND_CLASS_SUPERVISION.SUPERVISION_REPORT.ID)
            });
        }

        private byte[] CreateSupervisionCmd(byte[] data)
        {
            var ret = new COMMAND_CLASS_SUPERVISION.SUPERVISION_GET();
            ret.encapsulatedCommandLength = (byte)data.Length;
            ret.encapsulatedCommand = new List<byte>(data);
            return ret;
        }
    }
}
