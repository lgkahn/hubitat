﻿using System;
using System.Collections.Generic;
using ZWave.ZnifferApplication.Enums;
using ZWave.ZnifferApplication.Operations;
using ZWave.Layers;
using ZWave.Layers.Application;
using ZWave.Enums;
using ZWave.Xml.FrameHeader;

namespace ZWave.ZnifferApplication.Devices
{
    public class Zniffer : ApplicationClient
    {
        internal Zniffer(byte sessionId, ISessionClient sc, IFrameClient fc, ITransportClient tc)
            : base(ApiTypes.Zniffer, sessionId, sc, fc, tc)
        {
        }

        public FrameDefinition FrameDefinition { get; set; }
        public ZnifferApiVersion ApiVersion { get; set; }
        public int BaudRate { get; set; }
        public byte ChipRevision { get; set; }
        public byte ChipType { get; set; }
        public byte CustomFrequency { get; set; }
        public byte DefaultFrequency { get; set; }
        public int DefaultSpeed { get; set; }
        public byte[] Frequencies { get; set; }
        public byte Frequency { get; set; }
        public byte Revision { get; set; }
        public int Speed { get; set; }
        public string Uri { get; set; }
        public byte Version { get; set; }

        public ActionToken ExecuteAsync(IActionItem actionItem, Action<IActionItem> completedCallback)
        {
            actionItem.CompletedCallback = completedCallback;
            var action = actionItem as ActionBase;
            if (action != null)
            {
                action.Token.LogEntryPointCategory = "Zniffer";
                action.Token.LogEntryPointSource = DataSource == null ? "" : DataSource.SourceName;
            }
            return SessionClient.ExecuteAsync(actionItem);
        }

        public ActionResult Execute(IActionItem actionItem)
        {
            var action = actionItem as ActionBase;
            if (action != null)
            {
                action.Token.LogEntryPointCategory = "Zniffer";
                action.Token.LogEntryPointSource = DataSource == null ? "" : DataSource.SourceName;
            }
            var token = SessionClient.ExecuteAsync(actionItem);
            token.WaitCompletedSignal();
            return token.Result;
        }

        public GetVersionResult GetVersion()
        {
            GetVersionResult ret = null;
            GetVersionOperation op = new GetVersionOperation();
            ret = (GetVersionResult)Execute(op);
            AssignProperties(ret);
            return ret;
        }

        public ActionToken GetVersion(Action<IActionItem> completedCallback)
        {
            ActionToken ret = null;
            GetVersionOperation op = new GetVersionOperation();
            ret = op.Token;
            ExecuteAsync(op, (x) =>
            {
                var action = x as ActionBase;
                if (action != null)
                {
                    if (action.IsStateCompleted)
                    {
                        GetVersionResult res = (GetVersionResult)action.Result;
                        AssignProperties(res);
                    }
                    if (completedCallback != null)
                        completedCallback(action);
                }
            });
            return ret;
        }

        private void AssignProperties(GetVersionResult ret)
        {
            ChipType = ret.ChipType;
            ChipRevision = ret.ChipVersion;
            Version = ret.SnifferVersion;
            Revision = ret.SnifferRevision;
            ApiVersion = ret.ApiVersion;
            if (ApiVersion == ZnifferApiVersion.V3)
            {
                this.Frequency = ret.CurrentFrequency;
                // operation3x.SupportedFrequencies returns incorrect count use all frequencies (except 2.4Gz) instead

                //this.Frequencies = new byte[operation3x.SupportedFrequencies];
                //for (byte i = 0; i < this.Frequencies.Length; i++)
                //{
                //    this.Frequencies[i] = i;
                //}
                //for RU frequency 
                //for IL frequency 
                this.Frequencies = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 26, 27 };
            }
        }



        public ActionToken ExpectData(byte[] homeId, byte? nodeId, CollectDataOperation.DataItemPredicateDelegate dataItemPredicate, int timeoutMs, Action<IActionItem> completedCallback)
        {
            ExpectDataOperation op = new ExpectDataOperation(homeId, nodeId, dataItemPredicate, timeoutMs);
            return ExecuteAsync(op, completedCallback);
        }

        public ActionToken CollectData(byte[] homeId, byte? nodeId, CollectDataOperation.DataItemPredicateDelegate dataItemPredicate, int timeoutMs, Action<IActionItem> completedCallback)
        {
            CollectDataOperation op = new CollectDataOperation(homeId, nodeId, dataItemPredicate, timeoutMs);
            return ExecuteAsync(op, completedCallback);
        }

        public ActionToken ListenData(ListenDataOperation.DataItemCallbackDelegate dataItemCallback, Action<IActionItem> completedCallback)
        {
            ListenDataOperation op = new ListenDataOperation(dataItemCallback);
            return ExecuteAsync(op, completedCallback);
        }

        public bool Start()
        {
            bool ret = false;
            if (ApiVersion == ZnifferApiVersion.V4)
            {
                Start4xOperation operation = new Start4xOperation();
                Execute(operation);
                ret = operation.Token.State == ActionStates.Completed;
            }
            else
                ret = true;
            return ret;
        }

        public bool Stop()
        {
            bool ret = false;
            if (ApiVersion == ZnifferApiVersion.V4)
            {
                Stop4xOperation operation = new Stop4xOperation();
                Execute(operation);
                ret = operation.Token.State == ActionStates.Completed;
            }
            else
                ret = true;
            return ret;
        }


        public void SetFrequency(byte frequencyCode)
        {
            if (ApiVersion == ZnifferApiVersion.V3)
            {
                SetFrequency3xOperation operation = new SetFrequency3xOperation(frequencyCode);
                Execute(operation);
            }
            else if (ApiVersion == ZnifferApiVersion.V4)
            {
                byte code = frequencyCode;
                if (ChipType == 3 && code == 0x1A)
                    code = 0x0A;
                SetFrequency4xOperation operation = new SetFrequency4xOperation(code);
                Execute(operation);
            }
        }

        public Dictionary<byte, RFrequency> GetFrequencies()
        {
            Dictionary<byte, RFrequency> ret = new Dictionary<byte, RFrequency>();
            if (ApiVersion == ZnifferApiVersion.V4)
            {
                GetFrequencies4xOperation operation = new GetFrequencies4xOperation();
                Execute(operation);
                this.Frequency = operation.CurrentFrequency;
                if (ChipType == 3 && operation.CurrentFrequency == 0x0A)
                {
                    this.Frequency = 0x1A;
                }
                if (operation.Frequencies != null)
                {
                    this.Frequencies = new byte[operation.Frequencies.Length];
                    for (byte i = 0; i < this.Frequencies.Length; i++)
                    {
                        if (ChipType == 3 && operation.Frequencies[i] == 0x0A)
                        {
                            this.Frequencies[i] = 0x1A;
                        }
                        else
                        {
                            this.Frequencies[i] = operation.Frequencies[i];
                        }
                    }

                    for (byte i = 0; i < this.Frequencies.Length; i++)
                    {
                        GetFrequencyStr4xResult opres = (GetFrequencyStr4xResult)Execute(new GetFrequencyStr4xOperation(Frequencies[i]));
                        if (opres.IsStateCompleted)
                        {
                            ret.Add(Frequencies[i], new RFrequency(opres.Channels, opres.Name));
                        }
                        else
                            break;
                    }
                }
            }
            return ret;
        }

        public bool SetBaudRate(BaudRates baudRate)
        {
            SetBaudRate4xOperation operation = new SetBaudRate4xOperation(baudRate);
            Execute(operation);
            return operation.Token.State == ActionStates.Completed;
        }
    }
}
