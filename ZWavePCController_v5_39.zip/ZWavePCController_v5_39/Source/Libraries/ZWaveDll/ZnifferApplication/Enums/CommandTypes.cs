﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZWave.ZnifferApplication.Enums
{
    public enum CommandTypes
    {
        DataHandler = 0x00,

        
        GetVersion4x = 0x01,
        SetFrequency4x = 0x02, 
        GetFrequencies4x = 0x03,
        Start4x = 0x04,
        Stop4x = 0x05,
        SetBaudRate4x = 0x0E,
        GetFrequencyStr4x = 0x13,
        
        GetDeviceInfo3x = 0x49,
        SetFrequency3x = 0x46,
        GetDeviceInfo3xResponse = 0x26,
        SetFrequency3xResponse = 0x2E
    }
}
