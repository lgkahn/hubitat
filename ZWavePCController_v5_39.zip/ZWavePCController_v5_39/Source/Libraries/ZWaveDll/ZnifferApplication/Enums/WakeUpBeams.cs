﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZWave.ZnifferApplication.Enums
{
    public enum WakeUpBeamTypes
    {
        Impulse,
        Start,
        Stop
    }
}
