﻿namespace ZWave.BasicApplication.Enums
{
    public enum AssignStatuses
    {
        AssignComplete = 0x00,
        AssignNodeIdDone = 0x01,
        AssignRangeInfoUpdate = 0x02
    }
}
