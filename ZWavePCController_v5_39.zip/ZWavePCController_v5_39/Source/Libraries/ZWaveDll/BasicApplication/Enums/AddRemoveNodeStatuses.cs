﻿namespace ZWave.BasicApplication.Enums
{
    public enum AddRemoveNodeStatuses
    {
        None,
        Added,
        Replicated,
        Replaced
    }
}
