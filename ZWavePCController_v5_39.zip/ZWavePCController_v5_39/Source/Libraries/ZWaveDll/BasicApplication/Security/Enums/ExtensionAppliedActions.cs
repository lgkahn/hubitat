﻿
namespace ZWave.BasicApplication.Security
{
    public enum ExtensionAppliedActions
    {
        Add = 0,
        AddOrModify,
        ModifyIfExists,
        Delete
    }
}
